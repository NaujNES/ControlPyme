import { useState } from 'react';
import { Search, Plus, Edit, Trash2, AlertTriangle, AlertCircle, ChevronDown, X, Save } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import type { Product } from '../../context/AppContext';

// ─── Constants ────────────────────────────────────────────────────────────────

const CATEGORIES = ['Electrónica', 'Ropa', 'Alimentos', 'Hogar', 'Herramientas', 'Oficina', 'Otros'];

const STATUS_CONFIG = {
  'En Stock':   { bg: '#ecfdf5', color: '#065f46', dot: '#10b981' },
  'Bajo Stock': { bg: '#fffbeb', color: '#92400e', dot: '#f59e0b' },
  'Agotado':    { bg: '#fef2f2', color: '#991b1b', dot: '#ef4444' },
} as const;

// ─── Form type (no id, no status — context derives status) ────────────────────

type ProductForm = Omit<Product, 'id' | 'status'>;

const emptyForm = (): ProductForm => ({
  name: '',
  sku: '',
  category: 'Electrónica',
  stock: 0,
  purchasePrice: 0,
  salePrice: 0,
});

// ─── Shared style helpers ─────────────────────────────────────────────────────

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '9px 12px',
  border: '1px solid var(--surface-border)',
  borderRadius: 8,
  fontSize: 13.5,
  color: 'var(--slate-900)',
  background: 'var(--surface-card)',
  outline: 'none',
  boxSizing: 'border-box',
  fontFamily: 'inherit',
  transition: 'border-color 0.15s',
};

const cardStyle: React.CSSProperties = {
  background: 'var(--surface-card)',
  borderRadius: 'var(--radius-lg)',
  border: '1px solid var(--surface-border)',
  boxShadow: 'var(--shadow-sm)',
};

// ─── Inline Modal (no external dependency) ───────────────────────────────────

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  width?: number;
  children: React.ReactNode;
}

function Modal({ open, onClose, title, width = 520, children }: ModalProps) {
  if (!open) return null;
  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 1000,
        background: 'rgba(0,0,0,0.4)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 24, backdropFilter: 'blur(2px)',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: 'var(--surface-card)',
          borderRadius: 16,
          border: '1px solid var(--surface-border)',
          boxShadow: '0 20px 60px rgba(0,0,0,0.15)',
          width: '100%', maxWidth: width,
          maxHeight: '90vh',
          display: 'flex', flexDirection: 'column',
        }}
      >
        {/* Header */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '18px 24px',
          borderBottom: '1px solid var(--surface-border)',
          flexShrink: 0,
        }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, color: 'var(--slate-900)', letterSpacing: '-0.02em', margin: 0 }}>
            {title}
          </h2>
          <button
            onClick={onClose}
            style={{
              background: 'none', border: '1px solid var(--surface-border)',
              borderRadius: 7, padding: 6, cursor: 'pointer',
              color: 'var(--slate-500)', display: 'flex', alignItems: 'center',
            }}
          >
            <X size={15} />
          </button>
        </div>
        {/* Body */}
        <div style={{ padding: 24, overflowY: 'auto', flex: 1 }}>
          {children}
        </div>
      </div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export function Inventory() {
  const { products, addProduct, editProduct, deleteProduct, settings, lowStockCount, outOfStockCount, can } = useApp();

  const [search, setSearch]       = useState('');
  const [catFilter, setCatFilter] = useState('Todas');
  const [showModal, setShowModal] = useState(false);
  const [editTarget, setEditTarget] = useState<Product | null>(null);
  const [form, setForm]           = useState<ProductForm>(emptyForm());
  const [deleteId, setDeleteId]   = useState<string | null>(null);
  const [formError, setFormError] = useState('');

  // ── Handlers ────────────────────────────────────────────────────────────────

  const openAdd = () => {
    setEditTarget(null);
    setForm(emptyForm());
    setFormError('');
    setShowModal(true);
  };

  const openEdit = (p: Product) => {
    setEditTarget(p);
    setForm({
      name: p.name,
      sku: p.sku,
      category: p.category,
      stock: p.stock,
      purchasePrice: p.purchasePrice,
      salePrice: p.salePrice,
    });
    setFormError('');
    setShowModal(true);
  };

  const handleSave = async () => {
    if (!form.name.trim())  { setFormError('El nombre del producto es obligatorio.'); return; }
    if (!form.sku.trim())   { setFormError('El SKU es obligatorio.'); return; }
    if (form.salePrice <= 0){ setFormError('El precio de venta debe ser mayor a 0.'); return; }

    // Duplicate SKU check
    const duplicate = products.find(p => p.sku === form.sku && p.id !== editTarget?.id);
    if (duplicate) { setFormError(`El SKU "${form.sku}" ya está en uso.`); return; }

    try {
      if (editTarget) await editProduct(editTarget.id, {
        name: form.name,
        sku: form.sku,
        category: form.category,
        stock: form.stock,
        purchasePrice: form.purchasePrice,
        salePrice: form.salePrice,
      });
      else await addProduct({
        name: form.name,
        sku: form.sku,
        category: form.category,
        stock: form.stock,
        purchasePrice: form.purchasePrice,
        salePrice: form.salePrice,
      });
      setShowModal(false);
    } catch (error) {
      setFormError(error instanceof Error ? error.message : 'No se pudo guardar el producto.');
    }
  };

  const handleDelete = async () => {
    if (deleteId) {
      try {
        await deleteProduct(deleteId);
        setDeleteId(null);
      } catch (error) {
        setFormError(error instanceof Error ? error.message : 'No se pudo eliminar el producto.');
        setDeleteId(null);
      }
    }
  };

  // ── Filtering ────────────────────────────────────────────────────────────────

  const filtered = products.filter(p => {
    const matchSearch = (
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.sku.toLowerCase().includes(search.toLowerCase())
    );
    const matchCat = catFilter === 'Todas' || p.category === catFilter;
    return matchSearch && matchCat;
  });

  // ── Render ───────────────────────────────────────────────────────────────────

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>

      {/* ── Page Header ── */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 700, color: 'var(--slate-900)', letterSpacing: '-0.03em', margin: 0 }}>
            Inventario
          </h1>
          <p style={{ color: 'var(--slate-500)', fontSize: 13.5, marginTop: 4 }}>
            Gestión de productos y stock · {products.length} productos registrados
          </p>
        </div>
        {can('products:create') && <button
          onClick={openAdd}
          style={{
            background: 'var(--blue-500)', color: '#fff', border: 'none',
            borderRadius: 'var(--radius-md)', padding: '9px 16px',
            fontSize: 13.5, fontWeight: 600, fontFamily: 'inherit',
            display: 'flex', alignItems: 'center', gap: 7, cursor: 'pointer',
            boxShadow: '0 1px 2px rgba(37,99,235,0.3)',
          }}
        >
          <Plus size={16} />
          Agregar Producto
        </button>}
      </div>

      {/* ── Stock Alert Banners ── */}
      {(outOfStockCount > 0 || lowStockCount > 0) && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {outOfStockCount > 0 && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '10px 16px', borderRadius: 'var(--radius-md)',
              background: '#fef2f2', border: '1px solid #fecaca',
            }}>
              <AlertCircle size={16} color="#ef4444" />
              <span style={{ fontSize: 13, color: '#991b1b', fontWeight: 500 }}>
                {outOfStockCount} producto{outOfStockCount > 1 ? 's' : ''} agotado{outOfStockCount > 1 ? 's' : ''} — reposición urgente
              </span>
            </div>
          )}
          {lowStockCount > 0 && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '10px 16px', borderRadius: 'var(--radius-md)',
              background: '#fffbeb', border: '1px solid #fde68a',
            }}>
              <AlertTriangle size={16} color="#f59e0b" />
              <span style={{ fontSize: 13, color: '#92400e', fontWeight: 500 }}>
                {lowStockCount} producto{lowStockCount > 1 ? 's' : ''} con stock bajo (umbral: {settings.lowStockThreshold} uds) — revisar pronto
              </span>
            </div>
          )}
        </div>
      )}

      {/* ── Table Card ── */}
      <div className="animate-fade-in" style={cardStyle}>

        {/* Toolbar */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 12,
          padding: '16px 20px', borderBottom: '1px solid var(--surface-border)',
          flexWrap: 'wrap',
        }}>
          {/* Search */}
          <div style={{ flex: 1, minWidth: 200, position: 'relative' }}>
            <Search
              size={15}
              style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--slate-400)', pointerEvents: 'none' }}
            />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar por nombre o SKU…"
              style={{ ...inputStyle, paddingLeft: 36 }}
              onFocus={e => (e.target.style.borderColor = '#3b82f6')}
              onBlur={e => (e.target.style.borderColor = 'var(--surface-border)')}
            />
          </div>

          {/* Category filter */}
          <div style={{ position: 'relative' }}>
            <select
              value={catFilter}
              onChange={e => setCatFilter(e.target.value)}
              style={{ ...inputStyle, paddingRight: 32, width: 'auto', cursor: 'pointer' }}
            >
              <option value="Todas">Todas las categorías</option>
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <ChevronDown
              size={13}
              style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--slate-400)', pointerEvents: 'none' }}
            />
          </div>

          <span style={{ fontSize: 12, color: 'var(--slate-400)', whiteSpace: 'nowrap' }}>
            {filtered.length} producto{filtered.length !== 1 ? 's' : ''}
          </span>
        </div>

        {/* Table */}
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-bg)' }}>
                {['Producto', 'SKU', 'Categoría', 'Stock', 'Costo', 'Precio Venta', 'Estado', 'Acciones'].map(h => (
                  <th key={h} style={{
                    textAlign: 'left', padding: '11px 20px',
                    fontSize: 11.5, fontWeight: 600, color: 'var(--slate-500)',
                    letterSpacing: '0.04em', textTransform: 'uppercase',
                    borderBottom: '1px solid var(--surface-border)',
                    whiteSpace: 'nowrap',
                  }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((p, i) => {
                const sc = STATUS_CONFIG[p.status];
                return (
                  <tr
                    key={p.id}
                    style={{
                      borderBottom: i < filtered.length - 1 ? '1px solid var(--surface-border)' : 'none',
                      transition: 'background 0.12s',
                    }}
                    onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface-hover)')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                  >
                    {/* Name */}
                    <td style={{ padding: '14px 20px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                        <div style={{
                          width: 36, height: 36, borderRadius: 8, flexShrink: 0,
                          background: 'var(--surface-bg)', border: '1px solid var(--surface-border)',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          fontSize: 11, fontWeight: 700, color: 'var(--slate-500)',
                        }}>
                          {p.name.slice(0, 2).toUpperCase()}
                        </div>
                        <span style={{ fontSize: 13.5, fontWeight: 500, color: 'var(--slate-900)' }}>{p.name}</span>
                      </div>
                    </td>

                    {/* SKU */}
                    <td style={{ padding: '14px 20px' }}>
                      <code style={{
                        fontSize: 12, color: 'var(--slate-500)',
                        background: 'var(--surface-bg)', padding: '2px 6px',
                        borderRadius: 4, border: '1px solid var(--surface-border)',
                      }}>
                        {p.sku}
                      </code>
                    </td>

                    {/* Category */}
                    <td style={{ padding: '14px 20px', fontSize: 13, color: 'var(--slate-600)' }}>{p.category}</td>

                    {/* Stock */}
                    <td style={{ padding: '14px 20px' }}>
                      <span style={{
                        fontSize: 13.5, fontWeight: 600,
                        color: p.stock === 0 ? '#ef4444' : p.stock <= settings.lowStockThreshold ? '#f59e0b' : 'var(--slate-900)',
                      }}>
                        {p.stock}
                      </span>
                      <span style={{ fontSize: 11, color: 'var(--slate-400)', marginLeft: 4 }}>
                        uds
                      </span>
                    </td>

                    {/* Purchase price */}
                    <td style={{ padding: '14px 20px', fontSize: 13, color: 'var(--slate-600)' }}>
                      {settings.currencySymbol}{p.purchasePrice.toFixed(2)}
                    </td>

                    {/* Sale price */}
                    <td style={{ padding: '14px 20px', fontSize: 13.5, fontWeight: 500, color: 'var(--slate-900)' }}>
                      {settings.currencySymbol}{p.salePrice.toFixed(2)}
                    </td>

                    {/* Status badge */}
                    <td style={{ padding: '14px 20px' }}>
                      <div style={{
                        display: 'inline-flex', alignItems: 'center', gap: 6,
                        background: sc.bg, color: sc.color,
                        padding: '4px 10px', borderRadius: 'var(--radius-full)',
                      }}>
                        <div style={{ width: 6, height: 6, borderRadius: '50%', background: sc.dot, flexShrink: 0 }} />
                        <span style={{ fontSize: 12, fontWeight: 500 }}>{p.status}</span>
                      </div>
                    </td>

                    {/* Actions */}
                    <td style={{ padding: '14px 20px' }}>
                      <div style={{ display: 'flex', gap: 6 }}>
                        {can('products:update') && <button
                          onClick={() => openEdit(p)}
                          title="Editar producto"
                          style={{
                            background: 'none', border: '1px solid var(--surface-border)',
                            borderRadius: 6, padding: '6px 8px', cursor: 'pointer',
                            color: 'var(--slate-600)', display: 'flex', alignItems: 'center',
                          }}
                        >
                          <Edit size={13} />
                        </button>}
                        {can('products:delete') && <button
                          onClick={() => setDeleteId(p.id)}
                          title="Eliminar producto"
                          style={{
                            background: 'none', border: '1px solid #fecaca',
                            borderRadius: 6, padding: '6px 8px', cursor: 'pointer',
                            color: '#ef4444', display: 'flex', alignItems: 'center',
                          }}
                        >
                          <Trash2 size={13} />
                        </button>}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {filtered.length === 0 && (
            <div style={{ padding: '60px 0', textAlign: 'center', color: 'var(--slate-400)', fontSize: 13 }}>
              {search
                ? <>No se encontraron productos para "<strong>{search}</strong>"</>
                : 'No hay productos en esta categoría.'
              }
            </div>
          )}
        </div>
      </div>

      {/* ── Add / Edit Modal ── */}
      <Modal
        open={showModal}
        onClose={() => setShowModal(false)}
        title={editTarget ? 'Editar Producto' : 'Agregar Producto'}
        width={560}
      >
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

          {/* Error banner */}
          {formError && (
            <div style={{
              background: '#fef2f2', border: '1px solid #fecaca',
              borderRadius: 8, padding: '10px 14px',
              fontSize: 13, color: '#991b1b',
              display: 'flex', alignItems: 'center', gap: 8,
            }}>
              <X size={14} />{formError}
            </div>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>

            {/* Name — full width */}
            <div style={{ gridColumn: '1 / -1', display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Nombre del producto *</label>
              <input
                style={inputStyle}
                value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })}
                placeholder="Ej: Laptop Dell XPS 15"
                onFocus={e => (e.target.style.borderColor = '#3b82f6')}
                onBlur={e => (e.target.style.borderColor = 'var(--surface-border)')}
              />
            </div>

            {/* SKU */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>SKU *</label>
              <input
                style={inputStyle}
                value={form.sku}
                onChange={e => setForm({ ...form, sku: e.target.value })}
                placeholder="Ej: TECH-001"
                onFocus={e => (e.target.style.borderColor = '#3b82f6')}
                onBlur={e => (e.target.style.borderColor = 'var(--surface-border)')}
              />
            </div>

            {/* Category */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Categoría</label>
              <select
                style={{ ...inputStyle, cursor: 'pointer' }}
                value={form.category}
                onChange={e => setForm({ ...form, category: e.target.value })}
              >
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            {/* Stock */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Stock actual</label>
              <input
                type="number" min={0}
                style={inputStyle}
                value={form.stock}
                onChange={e => setForm({ ...form, stock: Number(e.target.value) })}
                onFocus={e => (e.target.style.borderColor = '#3b82f6')}
                onBlur={e => (e.target.style.borderColor = 'var(--surface-border)')}
              />
            </div>

            {/* Purchase price */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Precio de costo ({settings.currencySymbol})</label>
              <input
                type="number" min={0} step={0.01}
                style={inputStyle}
                value={form.purchasePrice}
                onChange={e => setForm({ ...form, purchasePrice: Number(e.target.value) })}
                onFocus={e => (e.target.style.borderColor = '#3b82f6')}
                onBlur={e => (e.target.style.borderColor = 'var(--surface-border)')}
              />
            </div>

            {/* Sale price */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Precio de venta * ({settings.currencySymbol})</label>
              <input
                type="number" min={0} step={0.01}
                style={inputStyle}
                value={form.salePrice}
                onChange={e => setForm({ ...form, salePrice: Number(e.target.value) })}
                onFocus={e => (e.target.style.borderColor = '#3b82f6')}
                onBlur={e => (e.target.style.borderColor = 'var(--surface-border)')}
              />
            </div>
          </div>

          {/* Margin preview */}
          {form.purchasePrice > 0 && form.salePrice > 0 && (
            <div style={{
              background: form.salePrice >= form.purchasePrice ? '#ecfdf5' : '#fef2f2',
              border: `1px solid ${form.salePrice >= form.purchasePrice ? '#86efac' : '#fecaca'}`,
              borderRadius: 8, padding: '10px 14px',
              fontSize: 13, color: form.salePrice >= form.purchasePrice ? '#065f46' : '#991b1b',
            }}>
              Margen bruto estimado:{' '}
              <strong>
                {settings.currencySymbol}{(form.salePrice - form.purchasePrice).toFixed(2)}
                {' '}({((form.salePrice - form.purchasePrice) / form.salePrice * 100).toFixed(1)}%)
              </strong>
            </div>
          )}

          {/* Footer buttons */}
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 4 }}>
            <button
              onClick={() => setShowModal(false)}
              style={{
                padding: '9px 18px', border: '1px solid var(--surface-border)',
                borderRadius: 8, background: 'var(--surface-card)', color: 'var(--slate-700)',
                fontSize: 13.5, cursor: 'pointer', fontFamily: 'inherit',
              }}
            >
              Cancelar
            </button>
            <button
              onClick={handleSave}
              style={{
                padding: '9px 18px', border: 'none',
                borderRadius: 8, background: 'var(--blue-500)', color: '#fff',
                fontSize: 13.5, fontWeight: 600, cursor: 'pointer',
                display: 'flex', alignItems: 'center', gap: 7, fontFamily: 'inherit',
              }}
            >
              <Save size={15} />
              {editTarget ? 'Guardar cambios' : 'Agregar producto'}
            </button>
          </div>
        </div>
      </Modal>

      {/* ── Delete Confirm Modal ── */}
      <Modal
        open={!!deleteId}
        onClose={() => setDeleteId(null)}
        title="Confirmar eliminación"
        width={400}
      >
        <p style={{ fontSize: 14, color: 'var(--slate-700)', marginBottom: 20, lineHeight: 1.5 }}>
          ¿Estás seguro de que deseas eliminar este producto? Esta acción <strong>no se puede deshacer</strong>.
        </p>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
          <button
            onClick={() => setDeleteId(null)}
            style={{
              padding: '9px 18px', border: '1px solid var(--surface-border)',
              borderRadius: 8, background: 'var(--surface-card)', color: 'var(--slate-700)',
              fontSize: 13.5, cursor: 'pointer', fontFamily: 'inherit',
            }}
          >
            Cancelar
          </button>
          <button
            onClick={handleDelete}
            style={{
              padding: '9px 18px', border: 'none',
              borderRadius: 8, background: '#ef4444', color: '#fff',
              fontSize: 13.5, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit',
            }}
          >
            Sí, eliminar
          </button>
        </div>
      </Modal>

    </div>
  );
}
