import { useState } from 'react';
import { ShoppingCart, Plus, CheckCircle, AlertCircle, Package } from 'lucide-react';
import { useApp } from '../../context/AppContext';

// ─── Shared styles ────────────────────────────────────────────────────────────

const card: React.CSSProperties = {
  background: 'var(--surface-card)',
  borderRadius: 'var(--radius-lg)',
  border: '1px solid var(--surface-border)',
  boxShadow: 'var(--shadow-sm)',
};

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '9px 12px',
  border: '1px solid var(--surface-border)',
  borderRadius: 8,
  fontSize: 13.5,
  color: 'var(--slate-900)',
  background: 'var(--surface-card)',
  outline: 'none',
  boxSizing: 'border-box',
  fontFamily: 'inherit',
  transition: 'border-color 0.15s',
};

// ─── Modal ────────────────────────────────────────────────────────────────────

interface ModalProps { open: boolean; onClose: () => void; title: string; children: React.ReactNode; }

function Modal({ open, onClose, title, children }: ModalProps) {
  if (!open) return null;
  return (
    <div onClick={onClose} style={{ position: 'fixed', inset: 0, zIndex: 1000, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, backdropFilter: 'blur(2px)' }}>
      <div onClick={e => e.stopPropagation()} style={{ background: 'var(--surface-card)', borderRadius: 16, border: '1px solid var(--surface-border)', boxShadow: '0 20px 60px rgba(0,0,0,0.15)', width: '100%', maxWidth: 560, maxHeight: '90vh', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 24px', borderBottom: '1px solid var(--surface-border)', flexShrink: 0 }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, color: 'var(--slate-900)', margin: 0 }}>{title}</h2>
          <button onClick={onClose} style={{ background: 'none', border: '1px solid var(--surface-border)', borderRadius: 7, padding: '5px 10px', cursor: 'pointer', fontSize: 13, color: 'var(--slate-500)', fontFamily: 'inherit' }}>✕</button>
        </div>
        <div style={{ padding: 24, overflowY: 'auto', flex: 1 }}>{children}</div>
      </div>
    </div>
  );
}

// ─── Component ────────────────────────────────────────────────────────────────

export function Sales() {
  const { products, sales, addSale, settings, can } = useApp();

  const [showModal, setShowModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [error, setError]       = useState('');
  const [success, setSuccess]   = useState('');
  const [saving, setSaving]     = useState(false);

  const availableProducts = products.filter(p => p.stock > 0);
  const selectedP = products.find(p => p.id === selectedProduct);
  const maxQty    = selectedP?.stock ?? 0;
  const subtotal  = selectedP ? selectedP.salePrice * quantity : 0;

  const openModal = () => {
    setSelectedProduct('');
    setQuantity(1);
    setError('');
    setSuccess('');
    setShowModal(true);
  };

  const handleSubmit = async () => {
    setError('');
    if (!selectedProduct) { setError('Selecciona un producto.'); return; }
    if (quantity <= 0)    { setError('La cantidad debe ser mayor a 0.'); return; }
    if (quantity > maxQty){ setError(`Stock insuficiente. Disponible: ${maxQty} unidades.`); return; }

    setSaving(true);
    try {
      await addSale(selectedProduct, quantity);
      setSuccess(`Venta registrada por ${settings.currencySymbol}${subtotal.toFixed(2)}. Stock descontado automáticamente.`);
      setTimeout(() => { setShowModal(false); setSuccess(''); }, 1800);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'No se pudo registrar la venta. Verifica el stock.');
    } finally {
      setSaving(false);
    }
  };

  const totalSales   = sales.reduce((s, v) => s + v.total, 0);
  const totalUnits   = sales.reduce((s, v) => s + v.quantity, 0);
  const fmt = (n: number) => n.toLocaleString('es-MX', { minimumFractionDigits: 2 });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 700, color: 'var(--slate-900)', letterSpacing: '-0.03em', margin: 0 }}>Ventas</h1>
          <p style={{ color: 'var(--slate-500)', fontSize: 13.5, marginTop: 4 }}>Registra ventas · el stock se descuenta automáticamente</p>
        </div>
        {can('sales:create') && <button onClick={openModal} style={{ background: 'var(--blue-500)', color: '#fff', border: 'none', borderRadius: 'var(--radius-md)', padding: '9px 16px', fontSize: 13.5, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 7, cursor: 'pointer', fontFamily: 'inherit' }}>
          <Plus size={16} /> Nueva Venta
        </button>}
      </div>

      {/* Summary */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 220px), 1fr))', gap: 16 }}>
        {[
          { label: 'Total en Ventas',      value: `${settings.currencySymbol}${fmt(totalSales)}`, color: '#10b981', bg: '#ecfdf5' },
          { label: 'Ventas Registradas',   value: sales.length.toString(),                        color: '#3b82f6', bg: '#eff6ff' },
          { label: 'Unidades Vendidas',     value: totalUnits.toString(),                          color: '#8b5cf6', bg: '#f5f3ff' },
        ].map((s, i) => (
          <div key={i} className={`animate-fade-in stagger-${i + 1}`} style={{ ...card, padding: 20 }}>
            <p style={{ fontSize: 12.5, color: 'var(--slate-500)', fontWeight: 500, marginBottom: 8 }}>{s.label}</p>
            <p style={{ fontSize: 26, fontWeight: 700, color: s.color, letterSpacing: '-0.03em', margin: 0 }}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Sales Table */}
      <div className="animate-fade-in" style={card}>
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--surface-border)' }}>
          <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--slate-900)', margin: 0 }}>Historial de Ventas</p>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-bg)' }}>
                {['Fecha', 'Producto', 'Cantidad', 'Precio Unit.', 'Total'].map(h => (
                  <th key={h} style={{ textAlign: 'left', padding: '11px 20px', fontSize: 11.5, fontWeight: 600, color: 'var(--slate-500)', letterSpacing: '0.04em', textTransform: 'uppercase', borderBottom: '1px solid var(--surface-border)', whiteSpace: 'nowrap' }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sales.map((s, i) => (
                <tr key={s.id}
                  style={{ borderBottom: i < sales.length - 1 ? '1px solid var(--surface-border)' : 'none', transition: 'background 0.12s' }}
                  onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface-hover)')}
                  onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                >
                  <td style={{ padding: '13px 20px', fontSize: 12.5, color: 'var(--slate-500)', whiteSpace: 'nowrap' }}>
                    {new Date(s.date + 'T12:00:00').toLocaleDateString('es-MX', { day: '2-digit', month: 'short', year: 'numeric' })}
                  </td>
                  <td style={{ padding: '13px 20px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ width: 30, height: 30, borderRadius: 7, background: '#eff6ff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <Package size={14} color="#3b82f6" />
                      </div>
                      <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--slate-900)' }}>{s.productName}</span>
                    </div>
                  </td>
                  <td style={{ padding: '13px 20px', fontSize: 13.5, fontWeight: 600, color: 'var(--slate-900)' }}>
                    {s.quantity} uds
                  </td>
                  <td style={{ padding: '13px 20px', fontSize: 13, color: 'var(--slate-600)' }}>
                    {settings.currencySymbol}{fmt(s.unitPrice)}
                  </td>
                  <td style={{ padding: '13px 20px', fontSize: 14, fontWeight: 700, color: '#059669', letterSpacing: '-0.02em' }}>
                    +{settings.currencySymbol}{fmt(s.total)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {sales.length === 0 && (
            <div style={{ padding: '60px 0', textAlign: 'center', color: 'var(--slate-400)', fontSize: 13 }}>
              Aún no hay ventas registradas. ¡Crea la primera!
            </div>
          )}
        </div>
      </div>

      {/* New Sale Modal */}
      <Modal open={showModal} onClose={() => setShowModal(false)} title="Registrar Nueva Venta">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>

          {error && (
            <div style={{ background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 8, padding: '10px 14px', fontSize: 13, color: '#991b1b', display: 'flex', alignItems: 'center', gap: 8 }}>
              <AlertCircle size={14} /> {error}
            </div>
          )}
          {success && (
            <div style={{ background: '#ecfdf5', border: '1px solid #86efac', borderRadius: 8, padding: '10px 14px', fontSize: 13, color: '#065f46', display: 'flex', alignItems: 'center', gap: 8 }}>
              <CheckCircle size={14} /> {success}
            </div>
          )}

          {/* Product selector */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Producto *</label>
            <select
              value={selectedProduct}
              onChange={e => { setSelectedProduct(e.target.value); setQuantity(1); setError(''); }}
              style={{ ...inputStyle, cursor: 'pointer' }}
              onFocus={e => (e.target.style.borderColor = '#3b82f6')}
              onBlur={e => (e.target.style.borderColor = 'var(--surface-border)')}
            >
              <option value="">— Selecciona un producto —</option>
              {availableProducts.map(p => (
                <option key={p.id} value={p.id}>
                  {p.name} · Stock: {p.stock} · {settings.currencySymbol}{p.salePrice.toFixed(2)}
                </option>
              ))}
            </select>
            {availableProducts.length === 0 && (
              <p style={{ fontSize: 12, color: '#f59e0b', marginTop: 4 }}>⚠ No hay productos disponibles con stock.</p>
            )}
          </div>

          {/* Quantity */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>
              Cantidad {selectedP && <span style={{ fontWeight: 400, color: 'var(--slate-500)' }}>(máx. {maxQty})</span>}
            </label>
            <input
              type="number"
              min={1}
              max={maxQty}
              value={quantity}
              onChange={e => { setQuantity(Math.max(1, +e.target.value)); setError(''); }}
              style={inputStyle}
              onFocus={e => (e.target.style.borderColor = '#3b82f6')}
              onBlur={e => (e.target.style.borderColor = 'var(--surface-border)')}
            />
          </div>

          {/* Product info + subtotal */}
          {selectedP && (
            <div style={{ background: 'var(--surface-bg)', border: '1px solid var(--surface-border)', borderRadius: 10, padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                <span style={{ color: 'var(--slate-500)' }}>Precio unitario</span>
                <span style={{ fontWeight: 600 }}>{settings.currencySymbol}{fmt(selectedP.salePrice)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                <span style={{ color: 'var(--slate-500)' }}>Stock disponible</span>
                <span style={{ fontWeight: 600, color: selectedP.stock <= 5 ? '#f59e0b' : 'var(--slate-900)' }}>
                  {selectedP.stock} unidades
                </span>
              </div>
              <div style={{ height: 1, background: 'var(--surface-border)' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 15 }}>
                <span style={{ fontWeight: 600 }}>Total</span>
                <span style={{ fontWeight: 700, color: '#059669', fontSize: 18 }}>
                  {settings.currencySymbol}{fmt(subtotal)}
                </span>
              </div>
            </div>
          )}

          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 4 }}>
            <button onClick={() => setShowModal(false)} style={{ padding: '9px 18px', border: '1px solid var(--surface-border)', borderRadius: 8, background: 'var(--surface-card)', color: 'var(--slate-700)', fontSize: 13.5, cursor: 'pointer', fontFamily: 'inherit' }}>
              Cancelar
            </button>
            <button onClick={handleSubmit} disabled={saving} style={{ padding: '9px 18px', border: 'none', borderRadius: 8, background: 'var(--blue-500)', color: '#fff', fontSize: 13.5, fontWeight: 600, cursor: saving ? 'wait' : 'pointer', opacity: saving ? 0.7 : 1, display: 'flex', alignItems: 'center', gap: 7, fontFamily: 'inherit' }}>
              <ShoppingCart size={15} /> {saving ? 'Registrando…' : 'Registrar Venta'}
            </button>
          </div>
        </div>
      </Modal>

    </div>
  );
}
