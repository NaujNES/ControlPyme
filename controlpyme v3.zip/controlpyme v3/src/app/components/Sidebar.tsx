import { useState } from 'react';
import {
  LayoutDashboard, Package, ShoppingCart, DollarSign,
  TrendingUp, Settings as SettingsIcon, ChevronsLeft, ChevronsRight,
  LogOut, Sun, Moon, Sparkles, Search, Bell, X,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useTheme } from '../../context/ThemeContext';

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const menuGroups = [
  {
    label: 'General',
    items: [
      { id: 'dashboard', label: 'Dashboard',  icon: LayoutDashboard },
      { id: 'inventory', label: 'Inventario', icon: Package },
      { id: 'sales',     label: 'Ventas',     icon: ShoppingCart },
    ],
  },
  {
    label: 'Analítica',
    items: [
      { id: 'finance', label: 'Finanzas', icon: DollarSign },
      { id: 'reports', label: 'Reportes', icon: TrendingUp },
    ],
  },
  {
    label: 'Sistema',
    items: [
      { id: 'settings', label: 'Configuración', icon: SettingsIcon },
    ],
  },
];

export function Sidebar({ activeSection, onSectionChange }: SidebarProps) {
  const { auth, logout, settings, lowStockCount, outOfStockCount, can, selectBusiness } = useApp();
  const { theme, toggleTheme } = useTheme();
  const [collapsed, setCollapsed] = useState(false);
  const [sidebarSearch, setSidebarSearch] = useState('');
  const W = collapsed ? 72 : 232;

  const permissionBySection: Record<string, string | string[]> = {
    inventory: 'products:read', sales: 'sales:read', finance: 'finance:read',
    reports: 'reports:read', settings: 'settings:read',
    dashboard: ['products:read', 'sales:read', 'finance:read', 'reports:read'],
  };
  const visibleGroups = menuGroups.map(group => ({
    ...group,
    items: group.items.filter(item => {
      const permission = permissionBySection[item.id];
      return !permission || (Array.isArray(permission) ? permission.some(can) : can(permission));
    }),
  })).filter(group => group.items.length > 0);
  const searchable = visibleGroups.flatMap(group => group.items.map(item => ({
    id: item.id, label: item.label, group: group.label, icon: item.icon,
  })));

  const alertCount = lowStockCount + outOfStockCount;
  const initials = (auth.user?.name ?? 'U').slice(0, 2).toUpperCase();

  const q = sidebarSearch.trim().toLowerCase();
  const searchResults = q
    ? searchable.filter(s => s.label.toLowerCase().includes(q) || s.id.toLowerCase().includes(q))
    : [];

  const handlePickResult = (id: string) => {
    onSectionChange(id);
    setSidebarSearch('');
  };

  return (
    <aside style={{
      width: W, minWidth: W, height: '100vh',
      background: 'var(--gradient-sidebar)',
      display: 'flex', flexDirection: 'column',
      transition: 'width 0.32s cubic-bezier(0.4,0,0.2,1), min-width 0.32s cubic-bezier(0.4,0,0.2,1), background 0.2s',
      position: 'relative', zIndex: 10,
    }}>
      {/* ─── Brand ─── */}
      <div style={{
        display: 'flex', alignItems: 'center',
        gap: 12, padding: collapsed ? '22px 0' : '22px 18px',
        justifyContent: collapsed ? 'center' : 'flex-start',
        borderBottom: '1px solid var(--sidebar-border)', minHeight: 72,
      }}>
        <div style={{
          width: 38, height: 38, flexShrink: 0,
          background: 'var(--gradient-brand)',
          borderRadius: 11,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 8px 20px rgba(37,99,235,0.35), inset 0 1px 0 rgba(255,255,255,0.2)',
          position: 'relative',
        }}>
          <Sparkles size={18} color="#fff" strokeWidth={2.4} />
        </div>
        {!collapsed && (
          <div style={{ minWidth: 0, flex: 1 }}>
            <p style={{
              color: 'var(--sidebar-text-active)', fontWeight: 700, fontSize: 15,
              letterSpacing: '-0.02em', lineHeight: 1.1, margin: 0,
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
            }}>
              {settings.businessName}
            </p>
            <p style={{
              color: 'var(--sidebar-text)', fontSize: 11, marginTop: 3,
              fontWeight: 500, letterSpacing: '0.04em', textTransform: 'uppercase',
            }}>
              ControlPyme
            </p>
          </div>
        )}
      </div>

      {!collapsed && auth.businesses.length > 1 && <div style={{ padding: '10px 14px', borderBottom: '1px solid var(--sidebar-border)' }}>
        <label style={{ color: 'var(--sidebar-text)', fontSize: 11, display: 'flex', flexDirection: 'column', gap: 5 }}>
          Negocio activo
          <select aria-label="Seleccionar negocio activo" value={auth.business?.id || ''} onChange={e => selectBusiness(e.target.value).catch(() => {})} style={{ width: '100%', borderRadius: 7, padding: '7px 8px', border: '1px solid var(--surface-border)', color: 'var(--text-primary)', background: 'var(--surface-card)', font: 'inherit', fontSize: 12 }}>
            {auth.businesses.map(business => <option key={business.id} value={business.id}>{business.name} · {business.roleName}</option>)}
          </select>
        </label>
      </div>}

      {/* ─── Quick row (search + bell) ─── */}
      {!collapsed && (
        <div style={{ padding: '14px 14px 6px', display: 'flex', gap: 8 }}>
          <div
            style={{
              flex: 1,
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '6px 10px',
              background: 'var(--sidebar-chip-bg)',
              border: '1px solid var(--sidebar-chip-border)',
              borderRadius: 8,
              minWidth: 0,
              transition: 'border-color 0.18s, background 0.18s',
            }}
          >
            <Search size={13} color="var(--sidebar-text)" style={{ flexShrink: 0 }} />
            <input
              type="text"
              value={sidebarSearch}
              onChange={e => setSidebarSearch(e.target.value)}
              placeholder="Buscar…"
              aria-label="Buscar"
              style={{
                flex: 1,
                minWidth: 0,
                background: 'transparent',
                border: 'none',
                outline: 'none',
                color: 'var(--sidebar-text-active)',
                fontSize: 12.5,
                padding: 0,
                fontFamily: 'inherit',
              }}
            />
            {sidebarSearch ? (
              <button
                type="button"
                onClick={() => setSidebarSearch('')}
                aria-label="Limpiar búsqueda"
                style={{
                  background: 'none',
                  border: 'none',
                  color: 'var(--sidebar-text)',
                  cursor: 'pointer',
                  padding: 0,
                  display: 'flex',
                  flexShrink: 0,
                }}
              >
                <X size={12} />
              </button>
            ) : (
              <kbd
                style={{
                  fontSize: 10,
                  padding: '1px 5px',
                  borderRadius: 4,
                  background: 'var(--sidebar-chip-border)',
                  border: '1px solid var(--sidebar-chip-bg-hover)',
                  color: 'var(--sidebar-text)',
                  flexShrink: 0,
                }}
              >
                ⌘K
              </kbd>
            )}
          </div>
          <button
            type="button"
            style={{
              width: 32,
              height: 32,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              background: 'var(--sidebar-chip-bg)',
              border: '1px solid var(--sidebar-chip-border)',
              borderRadius: 8,
              color: 'var(--sidebar-text)',
              cursor: 'pointer',
              position: 'relative',
              flexShrink: 0,
            }}
            title="Notificaciones"
            aria-label="Notificaciones"
          >
            <Bell size={14} />
            {alertCount > 0 && (
              <span
                style={{
                  position: 'absolute',
                  top: 5,
                  right: 5,
                  width: 7,
                  height: 7,
                  borderRadius: '50%',
                  background: '#ef4444',
                  boxShadow: '0 0 0 2px var(--sidebar-bg-elev)',
                }}
              />
            )}
          </button>
        </div>
      )}

      {/* ─── Search results ─── */}
      {!collapsed && sidebarSearch && (
        <div style={{ padding: '0 14px 8px' }}>
          {searchResults.length === 0 ? (
            <p style={{
              fontSize: 12, color: 'var(--sidebar-text)',
              padding: '8px 10px', margin: 0,
              background: 'var(--sidebar-chip-bg)',
              border: '1px solid var(--sidebar-chip-border)',
              borderRadius: 8,
            }}>
              Sin resultados para “{sidebarSearch}”
            </p>
          ) : (
            <div style={{
              display: 'flex', flexDirection: 'column', gap: 2,
              background: 'var(--sidebar-chip-bg)',
              border: '1px solid var(--sidebar-chip-border)',
              borderRadius: 8, padding: 4,
            }}>
              {searchResults.map(r => {
                const Icon = r.icon;
                return (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => handlePickResult(r.id)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 8,
                      padding: '7px 8px', border: 'none', borderRadius: 6,
                      background: 'transparent', cursor: 'pointer',
                      color: 'var(--sidebar-text-active)',
                      fontFamily: 'inherit', textAlign: 'left',
                    }}
                    onMouseEnter={e => (e.currentTarget.style.background = 'var(--sidebar-chip-bg-hover)')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                  >
                    <Icon size={14} color="var(--sidebar-accent)" />
                    <span style={{ fontSize: 12.5, fontWeight: 500, flex: 1 }}>{r.label}</span>
                    <span style={{ fontSize: 10, color: 'var(--sidebar-text)' }}>{r.group}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}


      {/* ─── Navigation ─── */}
      <nav style={{ flex: 1, padding: collapsed ? '14px 10px' : '10px 12px', overflowY: 'auto' }}>
        {visibleGroups.map((group, gi) => (
          <div key={group.label} style={{ marginTop: gi === 0 ? 4 : 18 }}>
            {!collapsed && (
              <p style={{
                fontSize: 10, fontWeight: 600, color: 'var(--sidebar-text)',
                letterSpacing: '0.08em', textTransform: 'uppercase',
                margin: '0 0 8px', paddingLeft: 12, opacity: 0.7,
              }}>
                {group.label}
              </p>
            )}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              {group.items.map(item => {
                const Icon = item.icon;
                const active = activeSection === item.id;
                const showBadge = item.id === 'inventory' && alertCount > 0;

                return (
                  <button
                    key={item.id}
                    onClick={() => onSectionChange(item.id)}
                    title={collapsed ? item.label : undefined}
                    style={{
                      width: '100%', display: 'flex', alignItems: 'center',
                      gap: 11, padding: collapsed ? '11px 0' : '10px 12px',
                      justifyContent: collapsed ? 'center' : 'flex-start',
                      borderRadius: 10, border: 'none',
                      background: active ? 'var(--sidebar-item-active)' : 'transparent',
                      color: active ? 'var(--sidebar-text-active)' : 'var(--sidebar-text)',
                      cursor: 'pointer',
                      transition: 'all 0.18s cubic-bezier(0.4,0,0.2,1)',
                      position: 'relative',
                    }}
                    onMouseEnter={e => { if (!active) (e.currentTarget as HTMLElement).style.background = 'var(--sidebar-item-hover)'; }}
                    onMouseLeave={e => { if (!active) (e.currentTarget as HTMLElement).style.background = 'transparent'; }}
                  >
                    {active && (
                      <span style={{
                        position: 'absolute', left: 0, top: '22%', bottom: '22%', width: 3,
                        background: 'var(--brand-400)',
                        borderRadius: '0 4px 4px 0',
                        boxShadow: '0 0 8px var(--brand-400)',
                      }} />
                    )}
                    <div style={{ position: 'relative', flexShrink: 0, display: 'flex' }}>
                      <Icon
                        size={18}
                        color={active ? 'var(--brand-400)' : 'currentColor'}
                        strokeWidth={active ? 2.2 : 1.8}
                      />
                      {showBadge && (
                        <span style={{
                          position: 'absolute', top: -5, right: -6,
                          minWidth: 15, height: 15, padding: '0 4px',
                          borderRadius: 8,
                          background: outOfStockCount > 0 ? '#ef4444' : '#f59e0b',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          fontSize: 9, fontWeight: 700, color: '#fff',
                          boxShadow: '0 0 0 2px var(--sidebar-bg)',
                        }}>
                          {alertCount > 9 ? '9+' : alertCount}
                        </span>
                      )}
                    </div>
                    {!collapsed && (
                      <span style={{
                        fontSize: 13.5, fontWeight: active ? 600 : 500,
                        letterSpacing: '-0.01em', whiteSpace: 'nowrap',
                        flex: 1, textAlign: 'left',
                      }}>
                        {item.label}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* ─── Theme toggle ─── */}
      <div style={{
        padding: collapsed ? '8px 10px' : '10px 14px',
        borderTop: '1px solid var(--sidebar-border)',
      }}>
        <button
          onClick={toggleTheme}
          title={`Cambiar a modo ${theme === 'dark' ? 'claro' : 'oscuro'}`}
          style={{
            width: '100%', display: 'flex', alignItems: 'center',
            gap: 10, padding: collapsed ? '9px 0' : '9px 12px',
            justifyContent: collapsed ? 'center' : 'flex-start',
            background: 'var(--sidebar-chip-bg)',
            border: '1px solid var(--sidebar-chip-border)',
            borderRadius: 10, color: 'var(--sidebar-text)',
            cursor: 'pointer', transition: 'all 0.18s',
          }}
          onMouseEnter={e => (e.currentTarget.style.background = 'var(--sidebar-chip-bg-hover)')}
          onMouseLeave={e => (e.currentTarget.style.background = 'var(--sidebar-chip-bg)')}
        >
          {theme === 'dark'
            ? <Sun size={15} color="var(--warning-400)" />
            : <Moon size={15} color="var(--brand-300)" />}
          {!collapsed && (
            <span style={{ fontSize: 12.5, fontWeight: 500, flex: 1, textAlign: 'left' }}>
              Modo {theme === 'dark' ? 'claro' : 'oscuro'}
            </span>
          )}
        </button>
      </div>

      {/* ─── User card ─── */}
      <div style={{
        padding: collapsed ? '10px' : '12px 14px 18px',
        borderTop: '1px solid var(--sidebar-border)',
      }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10,
          padding: collapsed ? 0 : 6,
          justifyContent: collapsed ? 'center' : 'flex-start',
          borderRadius: 10,
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: '50%', flexShrink: 0,
            background: 'var(--gradient-purple)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 12.5, fontWeight: 700, color: '#fff',
            boxShadow: '0 4px 12px rgba(139,92,246,0.35), inset 0 1px 0 rgba(255,255,255,0.2)',
            position: 'relative',
          }}>
            {initials}
            <span style={{
              position: 'absolute', bottom: -1, right: -1,
              width: 10, height: 10, borderRadius: '50%',
              background: '#10b981',
              boxShadow: '0 0 0 2px var(--sidebar-bg)',
            }} />
          </div>
          {!collapsed && (
            <>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{
                  color: 'var(--sidebar-text-active)', fontSize: 13, fontWeight: 600, margin: 0,
                  overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                }}>
                  {auth.user?.name ?? 'Usuario'}
                </p>
                <p style={{
                  color: 'var(--sidebar-text)', fontSize: 11, marginTop: 2,
                  overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                }}>
                  {auth.user?.email ?? ''}
                </p>
              </div>
              <button
                onClick={logout}
                title="Cerrar sesión"
                style={{
                  background: 'var(--sidebar-chip-bg)',
                  border: '1px solid var(--sidebar-chip-border)',
                  cursor: 'pointer', color: 'var(--sidebar-text)',
                  display: 'flex', padding: 7, borderRadius: 8,
                  flexShrink: 0, transition: 'all 0.18s',
                }}
                onMouseEnter={e => { e.currentTarget.style.color = '#fca5a5'; e.currentTarget.style.background = 'rgba(239,68,68,0.12)'; }}
                onMouseLeave={e => { e.currentTarget.style.color = 'var(--sidebar-text)'; e.currentTarget.style.background = 'var(--sidebar-chip-bg)'; }}
              >
                <LogOut size={14} />
              </button>
            </>
          )}
        </div>
      </div>

      {/* ─── Collapse toggle ─── */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        aria-label="Colapsar barra lateral"
        style={{
          position: 'absolute', right: -13, top: 56,
          width: 26, height: 26,
          background: 'var(--surface-card)',
          border: '1px solid var(--surface-border)',
          borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer', color: 'var(--text-secondary)', zIndex: 20,
          boxShadow: 'var(--shadow-md)',
          transition: 'transform 0.18s, box-shadow 0.18s',
        }}
        onMouseEnter={e => { e.currentTarget.style.transform = 'scale(1.08)'; e.currentTarget.style.boxShadow = 'var(--shadow-lg)'; }}
        onMouseLeave={e => { e.currentTarget.style.transform = 'scale(1)'; e.currentTarget.style.boxShadow = 'var(--shadow-md)'; }}
      >
        {collapsed ? <ChevronsRight size={13} /> : <ChevronsLeft size={13} />}
      </button>
    </aside>
  );
}
