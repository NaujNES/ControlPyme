import { useCallback, useEffect, useState } from 'react';
import { apiRequest, useApp } from '../../context/AppContext';

interface Permission { key: string; label: string }
interface Role { id: string; name: string; isSystem: boolean; permissions: string[] }
interface Member { id: string; name: string; email: string; isActive: boolean; roleId: string; roleName: string }

const card: React.CSSProperties = {
  background: 'var(--surface-card)', border: '1px solid var(--surface-border)',
  borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-sm)',
};
const input: React.CSSProperties = {
  width: '100%', padding: '9px 11px', border: '1px solid var(--surface-border)',
  borderRadius: 8, background: 'var(--surface-card)', color: 'var(--text-primary)',
  font: 'inherit', boxSizing: 'border-box',
};
const button: React.CSSProperties = {
  border: 0, borderRadius: 8, background: 'var(--brand-500)', color: '#fff',
  padding: '9px 14px', fontWeight: 600, cursor: 'pointer', font: 'inherit',
};

export function TeamAccess() {
  const { auth, can, selectBusiness } = useApp();
  const [roles, setRoles] = useState<Role[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [selectedRole, setSelectedRole] = useState('');
  const [roleName, setRoleName] = useState('');
  const [rolePermissions, setRolePermissions] = useState<string[]>([]);
  const [isNewRole, setIsNewRole] = useState(false);
  const [memberForm, setMemberForm] = useState({ name: '', email: '', password: '', roleId: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const load = useCallback(async () => {
    const result = await apiRequest<{ roles: Role[]; permissions: Permission[] }>('/roles');
    setRoles(result.roles);
    setPermissions(result.permissions);
    if (!selectedRole && result.roles.length) setSelectedRole(result.roles[0].id);
    if (auth.role === 'Propietario' || auth.permissions.includes('users:manage')) {
      setMembers(await apiRequest<Member[]>('/members'));
    } else setMembers([]);
  }, [auth.permissions, auth.role, selectedRole]);

  useEffect(() => { load().catch(err => setError(err.message)); }, [load]);

  useEffect(() => {
    const role = roles.find(item => item.id === selectedRole);
    if (role && !isNewRole) {
      setRoleName(role.name);
      setRolePermissions(role.permissions);
    }
  }, [roles, selectedRole, isNewRole]);

  const selected = roles.find(role => role.id === selectedRole);
  const ownerRole = selected?.name === 'Propietario';
  const canManageRoles = can('roles:manage');

  const reload = async (message: string) => {
    await load();
    setNotice(message);
    setError('');
  };

  const saveRole = async () => {
    setBusy(true); setError(''); setNotice('');
    try {
      const saved = isNewRole
        ? await apiRequest<Role>('/roles', { method: 'POST', body: JSON.stringify({ name: roleName, permissions: rolePermissions }) })
        : await apiRequest<Role>(`/roles/${selectedRole}`, { method: 'PUT', body: JSON.stringify({ name: roleName, permissions: rolePermissions }) });
      const refreshed = await apiRequest<{ roles: Role[]; permissions: Permission[] }>('/roles');
      setRoles(refreshed.roles); setPermissions(refreshed.permissions);
      setSelectedRole(saved.id); setIsNewRole(false); setNotice('Permisos del rol guardados.');
    } catch (err) { setError(err instanceof Error ? err.message : 'No se pudo guardar el rol.'); }
    finally { setBusy(false); }
  };

  const createRole = () => {
    setIsNewRole(true); setSelectedRole(''); setRoleName(''); setRolePermissions([]); setError(''); setNotice('');
  };

  const removeRole = async () => {
    if (!selected || selected.isSystem) return;
    setBusy(true); setError(''); setNotice('');
    try {
      await apiRequest(`/roles/${selected.id}`, { method: 'DELETE' });
      const refreshed = await apiRequest<{ roles: Role[]; permissions: Permission[] }>('/roles');
      setRoles(refreshed.roles); setPermissions(refreshed.permissions);
      setSelectedRole(refreshed.roles[0]?.id || ''); setIsNewRole(false); setNotice('Rol eliminado.');
    } catch (err) { setError(err instanceof Error ? err.message : 'No se pudo eliminar el rol.'); }
    finally { setBusy(false); }
  };

  const addMember = async (event: React.FormEvent) => {
    event.preventDefault(); setBusy(true); setError(''); setNotice('');
    try {
      await apiRequest('/members', { method: 'POST', body: JSON.stringify(memberForm) });
      setMemberForm({ name: '', email: '', password: '', roleId: '' });
      await reload('Usuario agregado al negocio. Entrégale su contraseña inicial de forma segura.');
    } catch (err) { setError(err instanceof Error ? err.message : 'No se pudo agregar el usuario.'); }
    finally { setBusy(false); }
  };

  const updateMember = async (member: Member, roleId: string, isActive = member.isActive) => {
    setBusy(true); setError(''); setNotice('');
    try {
      await apiRequest(`/members/${member.id}`, { method: 'PUT', body: JSON.stringify({ roleId, isActive }) });
      await reload('Acceso del usuario actualizado.');
    } catch (err) { setError(err instanceof Error ? err.message : 'No se pudo actualizar el usuario.'); }
    finally { setBusy(false); }
  };

  return <section style={{ ...card, padding: 24, display: 'flex', flexDirection: 'column', gap: 20 }}>
    <div>
      <h2 style={{ color: 'var(--text-primary)', fontSize: 18, margin: 0 }}>Usuarios, roles y permisos</h2>
      <p style={{ color: 'var(--text-secondary)', fontSize: 13, margin: '6px 0 0' }}>Los roles y usuarios de este negocio no afectan a los demás negocios.</p>
    </div>

    {auth.businesses.length > 1 && <label style={{ display: 'flex', flexDirection: 'column', gap: 6, maxWidth: 420, color: 'var(--text-secondary)', fontSize: 13 }}>
      Negocio activo
      <select style={input} value={auth.business?.id || ''} onChange={e => selectBusiness(e.target.value).catch(err => setError(err.message))}>
        {auth.businesses.map(business => <option key={business.id} value={business.id}>{business.name} · {business.roleName}</option>)}
      </select>
    </label>}

    {error && <div role="alert" style={{ color: 'var(--danger-text)', background: 'var(--danger-50)', padding: 10, borderRadius: 8, fontSize: 13 }}>{error}</div>}
    {notice && <div role="status" style={{ color: 'var(--success-text)', background: 'var(--success-50)', padding: 10, borderRadius: 8, fontSize: 13 }}>{notice}</div>}

    {canManageRoles && <div style={{ display: 'grid', gridTemplateColumns: 'minmax(180px, 0.8fr) minmax(280px, 1.5fr)', gap: 20 }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
          <strong style={{ color: 'var(--text-primary)', fontSize: 14 }}>Roles</strong>
          <button type="button" onClick={createRole} style={{ ...button, padding: '7px 10px', fontSize: 12 }}>Crear rol</button>
        </div>
        {roles.map(role => <button key={role.id} type="button" onClick={() => { setIsNewRole(false); setSelectedRole(role.id); }} style={{ textAlign: 'left', padding: '10px 12px', borderRadius: 8, border: '1px solid var(--surface-border)', background: selectedRole === role.id && !isNewRole ? 'var(--brand-50)' : 'var(--surface-card)', color: 'var(--text-primary)', cursor: 'pointer' }}>
          <span style={{ fontWeight: 600 }}>{role.name}</span>
          <span style={{ display: 'block', color: 'var(--text-secondary)', fontSize: 12, marginTop: 3 }}>{role.permissions.length} permisos{role.isSystem ? ' · predeterminado' : ''}</span>
        </button>)}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <label style={{ display: 'flex', flexDirection: 'column', gap: 6, color: 'var(--text-secondary)', fontSize: 13 }}>
          Nombre del rol
          <input style={input} value={roleName} disabled={ownerRole || busy} onChange={e => setRoleName(e.target.value)} placeholder="Ej. Bodega" />
        </label>
        <strong style={{ color: 'var(--text-primary)', fontSize: 14 }}>Permisos</strong>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: 8 }}>
          {permissions.map(permission => <label key={permission.key} style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--text-secondary)', fontSize: 12.5, padding: '8px 10px', border: '1px solid var(--surface-border)', borderRadius: 8 }}>
            <input type="checkbox" checked={ownerRole || rolePermissions.includes(permission.key)} disabled={ownerRole || busy} onChange={e => setRolePermissions(current => e.target.checked ? [...new Set([...current, permission.key])] : current.filter(key => key !== permission.key))} />
            {permission.label}
          </label>)}
        </div>
        {ownerRole && <p style={{ fontSize: 12, color: 'var(--text-secondary)', margin: 0 }}>El propietario conserva todos los permisos para no perder el control del negocio.</p>}
        {!ownerRole && <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button type="button" disabled={busy || !roleName.trim()} onClick={saveRole} style={{ ...button, opacity: busy || !roleName.trim() ? 0.6 : 1 }}>{busy ? 'Guardando…' : 'Guardar rol y permisos'}</button>
          {selected && !selected.isSystem && <button type="button" disabled={busy} onClick={removeRole} style={{ ...button, background: 'var(--danger-500)' }}>Eliminar rol</button>}
        </div>}
      </div>
    </div>}

    {can('users:manage') && <div style={{ borderTop: '1px solid var(--surface-border)', paddingTop: 18, display: 'flex', flexDirection: 'column', gap: 12 }}>
      <strong style={{ color: 'var(--text-primary)', fontSize: 14 }}>Usuarios del negocio</strong>
      {members.map(member => <div key={member.id} style={{ display: 'grid', gridTemplateColumns: 'minmax(120px, 1fr) minmax(150px, 1fr) auto', alignItems: 'center', gap: 10, borderBottom: '1px solid var(--surface-border)', padding: '9px 0' }}>
        <span style={{ color: 'var(--text-primary)', fontSize: 13 }}>{member.name}<small style={{ display: 'block', color: 'var(--text-secondary)' }}>{member.email}</small></span>
        <select style={input} value={member.roleId} disabled={busy || member.roleName === 'Propietario'} onChange={e => updateMember(member, e.target.value)}>
          {roles.map(role => <option key={role.id} value={role.id}>{role.name}</option>)}
        </select>
        <button type="button" disabled={busy || member.roleName === 'Propietario'} onClick={() => updateMember(member, member.roleId, !member.isActive)} style={{ ...button, background: member.isActive ? 'var(--surface-muted)' : 'var(--success-500)', color: member.isActive ? 'var(--text-primary)' : '#fff', padding: '7px 10px', fontSize: 12 }}>
          {member.isActive ? 'Desactivar' : 'Activar'}
        </button>
      </div>)}
      <form onSubmit={addMember} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', alignItems: 'end', gap: 10, marginTop: 6 }}>
        <label style={{ display: 'flex', flexDirection: 'column', gap: 5, color: 'var(--text-secondary)', fontSize: 12 }}>Nombre<input required style={input} value={memberForm.name} onChange={e => setMemberForm({ ...memberForm, name: e.target.value })} /></label>
        <label style={{ display: 'flex', flexDirection: 'column', gap: 5, color: 'var(--text-secondary)', fontSize: 12 }}>Correo<input required type="email" style={input} value={memberForm.email} onChange={e => setMemberForm({ ...memberForm, email: e.target.value })} /></label>
        <label style={{ display: 'flex', flexDirection: 'column', gap: 5, color: 'var(--text-secondary)', fontSize: 12 }}>Contraseña inicial<input required minLength={10} type="password" style={input} value={memberForm.password} onChange={e => setMemberForm({ ...memberForm, password: e.target.value })} /></label>
        <label style={{ display: 'flex', flexDirection: 'column', gap: 5, color: 'var(--text-secondary)', fontSize: 12 }}>Rol<select required style={input} value={memberForm.roleId} onChange={e => setMemberForm({ ...memberForm, roleId: e.target.value })}><option value="">Selecciona un rol</option>{roles.filter(role => role.name !== 'Propietario').map(role => <option key={role.id} value={role.id}>{role.name}</option>)}</select></label>
        <button type="submit" disabled={busy || !memberForm.roleId} style={{ ...button, opacity: busy || !memberForm.roleId ? 0.6 : 1 }}>Agregar usuario</button>
      </form>
      <p style={{ color: 'var(--text-secondary)', fontSize: 12, margin: 0 }}>El sistema no envía correos todavía. Comparte la contraseña inicial por un canal seguro; el usuario podrá iniciar sesión con su correo.</p>
    </div>}
  </section>;
}
