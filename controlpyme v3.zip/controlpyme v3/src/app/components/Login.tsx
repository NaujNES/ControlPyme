import { useState } from 'react';
import {
  Sparkles, Eye, EyeOff, LogIn, User, Lock, ArrowRight,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

const inputStyle: React.CSSProperties = {
  width: '100%', border: '1px solid var(--surface-border)', borderRadius: 10,
  color: 'var(--text-primary)', background: 'var(--surface-card)',
  outline: 'none', boxSizing: 'border-box', fontFamily: 'inherit', fontSize: 14,
};

export function Login() {
  const { login, registerBusiness } = useApp();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [businessName, setBusinessName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setError('');
    if (mode === 'register' && !businessName.trim()) { setError('Ingresa el nombre del negocio'); return; }
    if (mode === 'register' && !ownerName.trim()) { setError('Ingresa tu nombre'); return; }
    if (!username.trim()) { setError('Ingresa tu correo electrónico'); return; }
    if (!password.trim()) { setError('Ingresa tu contraseña'); return; }
    if (mode === 'register' && password.length < 10) { setError('La contraseña debe tener al menos 10 caracteres'); return; }
    setLoading(true);
    const ok = mode === 'register'
      ? await registerBusiness({ businessName: businessName.trim(), name: ownerName.trim(), email: username.trim(), password })
      : await login(username.trim(), password);
    if (!ok) setError(mode === 'register' ? 'No se pudo crear la cuenta. Verifica los datos o que el correo no esté registrado.' : 'Correo o contraseña inválidos');
    setLoading(false);
  };

  const onKey = (e: React.KeyboardEvent) => { if (e.key === 'Enter') handleSubmit(); };

  return (
    <div
      style={{
        minHeight: '100vh',
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 'clamp(16px, 4vw, 32px)',
        background: 'var(--surface-bg)',
      }}
    >
      <div
        className="animate-scale-in"
        style={{
          width: '100%',
          maxWidth: 400,
          display: 'flex',
          flexDirection: 'column',
          gap: 24,
        }}
      >
        {/* Discrete branding — Stripe / Linear / GitHub style */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 10,
            marginBottom: 4,
          }}
        >
          <div
            style={{
              width: 34,
              height: 34,
              borderRadius: 9,
              background: 'var(--gradient-brand)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 4px 12px rgba(37,99,235,0.30)',
            }}
          >
            <Sparkles size={16} color="#fff" strokeWidth={2.4} />
          </div>
          <span
            style={{
              fontSize: 16,
              fontWeight: 700,
              color: 'var(--text-primary)',
              letterSpacing: '-0.02em',
            }}
          >
            ControlPyme
          </span>
        </div>

        {/* Form card */}
        <div
          style={{
            background: 'var(--surface-card)',
            border: '1px solid var(--surface-border)',
            borderRadius: 14,
            padding: 28,
            boxShadow: 'var(--shadow-sm)',
            display: 'flex',
            flexDirection: 'column',
            gap: 22,
          }}
        >
          {/* Heading */}
          <div style={{ textAlign: 'center' }}>
            <h1
              style={{
                margin: 0,
                fontSize: 20,
                fontWeight: 700,
                color: 'var(--text-primary)',
                letterSpacing: '-0.02em',
              }}
            >
              {mode === 'login' ? 'Inicia sesión en tu cuenta' : 'Registra tu negocio'}
            </h1>
            <p
              style={{
                margin: '6px 0 0',
                fontSize: 13.5,
                color: 'var(--text-secondary)',
              }}
            >
              {mode === 'login' ? 'Ingresa tus credenciales para acceder al panel.' : 'Crea el negocio y la cuenta de propietario.'}
            </p>
          </div>

          {mode === 'register' && <div
            style={{
              background: 'var(--surface-muted)',
              border: '1px solid var(--surface-border)',
              borderRadius: 10,
              padding: '9px 12px',
              display: 'flex',
              alignItems: 'center',
              gap: 8,
            }}
          >
            <span
              className="animate-pulse-dot"
              style={{
                width: 7,
                height: 7,
                borderRadius: '50%',
                background: '#10b981',
                boxShadow: '0 0 0 3px rgba(16,185,129,0.18)',
                flexShrink: 0,
              }}
            />
            <p style={{ fontSize: 12.5, color: 'var(--text-secondary)', margin: 0 }}>
              Cada negocio tendrá sus propios datos. La contraseña debe tener al menos 10 caracteres.
            </p>
          </div>}

          {/* Form */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {mode === 'register' && <>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <label htmlFor="cp-business" style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text-primary)' }}>Nombre del negocio</label>
                <input id="cp-business" value={businessName} onChange={e => { setBusinessName(e.target.value); setError(''); }} placeholder="Mi negocio" style={{ ...inputStyle, padding: '10px 12px' }} />
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <label htmlFor="cp-owner" style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text-primary)' }}>Tu nombre</label>
                <input id="cp-owner" value={ownerName} onChange={e => { setOwnerName(e.target.value); setError(''); }} placeholder="Nombre completo" style={{ ...inputStyle, padding: '10px 12px' }} />
              </div>
            </>}
            {/* Username */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label
                htmlFor="cp-username"
                style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text-primary)' }}
              >
                Correo electrónico
              </label>
              <div style={{ position: 'relative' }}>
                <User
                  size={15}
                  style={{
                    position: 'absolute',
                    left: 12,
                    top: '50%',
                    transform: 'translateY(-50%)',
                    color: 'var(--text-subtle)',
                    pointerEvents: 'none',
                  }}
                />
                <input
                  id="cp-username"
                  name="username"
                  type="email"
                  autoComplete="email"
                  value={username}
                  onChange={e => { setUsername(e.target.value); setError(''); }}
                  onKeyDown={onKey}
                  placeholder="tu@correo.com"
                  autoFocus
                  style={{
                    width: '100%',
                    padding: '10px 12px 10px 36px',
                    border: `1px solid ${error && !username ? 'var(--danger-500)' : 'var(--surface-border)'}`,
                    borderRadius: 10,
                    fontSize: 14,
                    color: 'var(--text-primary)',
                    background: 'var(--surface-card)',
                    outline: 'none',
                    boxSizing: 'border-box',
                    fontFamily: 'inherit',
                    transition: 'border-color 0.18s, box-shadow 0.18s',
                  }}
                  onFocus={e => { e.target.style.borderColor = 'var(--brand-500)'; e.target.style.boxShadow = 'var(--shadow-ring)'; }}
                  onBlur={e => { e.target.style.borderColor = error && !username ? 'var(--danger-500)' : 'var(--surface-border)'; e.target.style.boxShadow = 'none'; }}
                />
              </div>
            </div>

            {/* Password */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <label
                  htmlFor="cp-password"
                  style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text-primary)' }}
                >
                  Contraseña
                </label>
                {mode === 'login' && <button
                  type="button"
                  style={{
                    fontSize: 12,
                    fontWeight: 500,
                    color: 'var(--brand-600)',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    padding: 0,
                    fontFamily: 'inherit',
                  }}
                >
                  ¿Olvidaste tu contraseña?
                </button>}
              </div>
              <div style={{ position: 'relative' }}>
                <Lock
                  size={15}
                  style={{
                    position: 'absolute',
                    left: 12,
                    top: '50%',
                    transform: 'translateY(-50%)',
                    color: 'var(--text-subtle)',
                    pointerEvents: 'none',
                  }}
                />
                <input
                  id="cp-password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  value={password}
                  onChange={e => { setPassword(e.target.value); setError(''); }}
                  onKeyDown={onKey}
                  placeholder="••••••••"
                  style={{
                    width: '100%',
                    padding: '10px 40px 10px 36px',
                    border: `1px solid ${error && !password ? 'var(--danger-500)' : 'var(--surface-border)'}`,
                    borderRadius: 10,
                    fontSize: 14,
                    color: 'var(--text-primary)',
                    background: 'var(--surface-card)',
                    outline: 'none',
                    boxSizing: 'border-box',
                    fontFamily: 'inherit',
                    transition: 'border-color 0.18s, box-shadow 0.18s',
                  }}
                  onFocus={e => { e.target.style.borderColor = 'var(--brand-500)'; e.target.style.boxShadow = 'var(--shadow-ring)'; }}
                  onBlur={e => { e.target.style.borderColor = error && !password ? 'var(--danger-500)' : 'var(--surface-border)'; e.target.style.boxShadow = 'none'; }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(s => !s)}
                  aria-label={showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}
                  style={{
                    position: 'absolute',
                    right: 8,
                    top: '50%',
                    transform: 'translateY(-50%)',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    color: 'var(--text-subtle)',
                    padding: 6,
                    display: 'flex',
                    borderRadius: 6,
                  }}
                >
                  {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div
                className="animate-fade-in"
                style={{
                  background: 'var(--danger-50)',
                  border: '1px solid var(--danger-100)',
                  borderRadius: 8,
                  padding: '8px 12px',
                  fontSize: 12.5,
                  color: 'var(--danger-text)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                }}
              >
                <span
                  style={{
                    width: 6,
                    height: 6,
                    borderRadius: '50%',
                    background: 'var(--danger-500)',
                    flexShrink: 0,
                  }}
                />
                {error}
              </div>
            )}

            {/* Submit */}
            <button
              onClick={handleSubmit}
              disabled={loading}
              style={{
                background: loading ? 'var(--brand-300)' : 'var(--gradient-brand)',
                color: '#fff',
                border: 'none',
                borderRadius: 10,
                padding: '11px 16px',
                fontSize: 14,
                fontWeight: 600,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8,
                cursor: loading ? 'not-allowed' : 'pointer',
                boxShadow: loading ? 'none' : '0 1px 2px rgba(37,99,235,0.30)',
                transition: 'transform 0.18s, box-shadow 0.18s, opacity 0.18s',
                marginTop: 2,
                fontFamily: 'inherit',
              }}
              onMouseEnter={e => { if (!loading) e.currentTarget.style.transform = 'translateY(-1px)'; }}
              onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; }}
            >
              {loading ? (
                <>
                  <span
                    style={{
                      width: 14,
                      height: 14,
                      border: '2px solid rgba(255,255,255,0.4)',
                      borderTopColor: '#fff',
                      borderRadius: '50%',
                      animation: 'spin 0.7s linear infinite',
                    }}
                  />
                  Ingresando…
                </>
              ) : (
                <>
                  <LogIn size={15} />
                  {mode === 'login' ? 'Ingresar al panel' : 'Crear negocio'}
                  <ArrowRight size={15} />
                </>
              )}
            </button>
          </div>

          <p style={{ textAlign: 'center', margin: 0, color: 'var(--text-secondary)', fontSize: 13 }}>
            {mode === 'login' ? '¿Primera vez aquí?' : '¿Ya tienes una cuenta?'}{' '}
            <button type="button" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(''); }} style={{ border: 0, background: 'none', color: 'var(--brand-600)', font: 'inherit', fontWeight: 600, cursor: 'pointer' }}>
              {mode === 'login' ? 'Registra tu negocio' : 'Inicia sesión'}
            </button>
          </p>
        </div>

        {/* Footer */}
        <p
          style={{
            textAlign: 'center',
            fontSize: 12,
            color: 'var(--text-subtle)',
            margin: 0,
          }}
        >
          © 2026 ControlPyme · Al continuar aceptas los términos y la política de privacidad.
        </p>
      </div>
    </div>
  );
}
