import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';
import { useApp } from '../../context/AppContext';

const PIE_COLORS = ['#3b82f6','#8b5cf6','#10b981','#f59e0b','#ef4444','#06b6d4'];

const card: React.CSSProperties = {
  background: 'var(--surface-card)',
  borderRadius: 'var(--radius-lg)',
  border: '1px solid var(--surface-border)',
  boxShadow: 'var(--shadow-sm)',
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: 'var(--slate-900)', color: '#fff', padding: '8px 12px', borderRadius: 8, fontSize: 12, boxShadow: 'var(--shadow-lg)' }}>
      <p style={{ color: 'var(--slate-400)', fontSize: 11, marginBottom: 4 }}>{label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} style={{ color: p.color ?? '#fff', marginBottom: 2 }}>
          {p.name}: <strong>{typeof p.value === 'number' && p.value > 999 ? `$${p.value.toLocaleString()}` : p.value}</strong>
        </p>
      ))}
    </div>
  );
};

export function Reports() {
  const { transactions, sales, products, settings } = useApp();

  const fmt = (n: number) => n.toLocaleString('es-MX', { minimumFractionDigits: 0 });

  // ── Computed totals ────────────────────────────────────────────────────────
  const totalIncome   = transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const totalExpenses = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const netProfit     = totalIncome - totalExpenses;
  const margin        = totalIncome > 0 ? ((netProfit / totalIncome) * 100).toFixed(1) : '0.0';
  const totalSalesRev = sales.reduce((s, v) => s + v.total, 0);
  const avgTicket     = sales.length > 0 ? totalSalesRev / sales.length : 0;

  // ── Monthly data (last 6 months) ───────────────────────────────────────────
  const MONTHS = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
  const now = new Date();
  const monthlyData = Array.from({ length: 6 }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - 5 + i, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const ingresos = transactions.filter(t => t.type === 'income'  && t.date.startsWith(key)).reduce((s, t) => s + t.amount, 0);
    const gastos   = transactions.filter(t => t.type === 'expense' && t.date.startsWith(key)).reduce((s, t) => s + t.amount, 0);
    const ventas   = sales.filter(v => v.date.startsWith(key)).reduce((s, v) => s + v.total, 0);
    return { month: MONTHS[d.getMonth()], ingresos, gastos, ventas };
  });

  // ── Category breakdown (income transactions) ───────────────────────────────
  const catMap: Record<string, number> = {};
  transactions.filter(t => t.type === 'income').forEach(t => {
    catMap[t.category] = (catMap[t.category] ?? 0) + t.amount;
  });
  const categoryData = Object.entries(catMap)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);

  // ── Top sold products ──────────────────────────────────────────────────────
  const productMap: Record<string, { name: string; qty: number; revenue: number }> = {};
  sales.forEach(s => {
    if (!productMap[s.productId]) productMap[s.productId] = { name: s.productName, qty: 0, revenue: 0 };
    productMap[s.productId].qty     += s.quantity;
    productMap[s.productId].revenue += s.total;
  });
  const topProducts = Object.values(productMap).sort((a, b) => b.revenue - a.revenue).slice(0, 5);

  // ── Stock status ───────────────────────────────────────────────────────────
  const stockSummary = [
    { name: 'En Stock',   value: products.filter(p => p.status === 'En Stock').length,   color: '#10b981' },
    { name: 'Bajo Stock', value: products.filter(p => p.status === 'Bajo Stock').length, color: '#f59e0b' },
    { name: 'Agotado',    value: products.filter(p => p.status === 'Agotado').length,    color: '#ef4444' },
  ].filter(d => d.value > 0);

  // ── Recent transactions ────────────────────────────────────────────────────
  const recentTx = [...transactions].slice(0, 8);

  const kpis = [
    { label: 'Ingresos Totales',   value: `${settings.currencySymbol}${fmt(totalIncome)}`,   color: '#10b981', bg: '#ecfdf5' },
    { label: 'Gastos Totales',     value: `${settings.currencySymbol}${fmt(totalExpenses)}`, color: '#ef4444', bg: '#fef2f2' },
    { label: 'Ganancia Neta',      value: `${settings.currencySymbol}${fmt(netProfit)}`,     color: netProfit >= 0 ? '#3b82f6' : '#f59e0b', bg: netProfit >= 0 ? '#eff6ff' : '#fffbeb' },
    { label: 'Margen de Ganancia', value: `${margin}%`,                                      color: '#8b5cf6', bg: '#f5f3ff' },
    { label: 'Total en Ventas',    value: `${settings.currencySymbol}${fmt(totalSalesRev)}`, color: '#06b6d4', bg: '#ecfeff' },
    { label: 'Ticket Promedio',    value: `${settings.currencySymbol}${avgTicket.toFixed(2)}`, color: '#f59e0b', bg: '#fffbeb' },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>

      {/* Header */}
      <div>
        <h1 style={{ fontSize: 24, fontWeight: 700, color: 'var(--slate-900)', letterSpacing: '-0.03em', margin: 0 }}>
          Reportes y Análisis
        </h1>
        <p style={{ color: 'var(--slate-500)', fontSize: 13.5, marginTop: 4 }}>
          Métricas en tiempo real · {settings.businessName}
        </p>
      </div>

      {/* KPI grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px,1fr))', gap: 14 }}>
        {kpis.map((k, i) => (
          <div key={i} className={`animate-fade-in stagger-${Math.min(i+1,4)}`} style={{ ...card, padding: 18 }}>
            <p style={{ fontSize: 11.5, fontWeight: 500, color: 'var(--slate-500)', marginBottom: 8 }}>{k.label}</p>
            <p style={{ fontSize: 22, fontWeight: 700, color: k.color, letterSpacing: '-0.03em', margin: 0 }}>{k.value}</p>
          </div>
        ))}
      </div>

      {/* Charts row 1 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>

        {/* Area chart — income vs expenses */}
        <div style={{ ...card, padding: 24 }}>
          <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--slate-900)', marginBottom: 2 }}>Ingresos vs Gastos</p>
          <p style={{ fontSize: 12, color: 'var(--slate-500)', marginBottom: 20 }}>Últimos 6 meses</p>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={monthlyData}>
              <defs>
                <linearGradient id="gI" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#3b82f6" stopOpacity={0.15}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="gG" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#ef4444" stopOpacity={0.10}/>
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--surface-border)" vertical={false}/>
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: 'var(--slate-500)' }} axisLine={false} tickLine={false}/>
              <YAxis tick={{ fontSize: 11, fill: 'var(--slate-400)' }} axisLine={false} tickLine={false} tickFormatter={v => v > 0 ? `$${v/1000}k` : '0'}/>
              <Tooltip content={<CustomTooltip />}/>
              <Area type="monotone" dataKey="ingresos" name="Ingresos" stroke="#3b82f6" strokeWidth={2.5} fill="url(#gI)"/>
              <Area type="monotone" dataKey="gastos"   name="Gastos"   stroke="#ef4444" strokeWidth={2}   fill="url(#gG)"/>
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Income by category pie */}
        <div style={{ ...card, padding: 24 }}>
          <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--slate-900)', marginBottom: 2 }}>Ingresos por Categoría</p>
          <p style={{ fontSize: 12, color: 'var(--slate-500)', marginBottom: 16 }}>Distribución de fuentes de ingreso</p>
          {categoryData.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={150}>
                <PieChart>
                  <Pie data={categoryData} cx="50%" cy="50%" innerRadius={40} outerRadius={65} dataKey="value" paddingAngle={3}>
                    {categoryData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} stroke="none"/>)}
                  </Pie>
                  <Tooltip formatter={(v: any) => [`${settings.currencySymbol}${v.toLocaleString()}`]} contentStyle={{ background: 'var(--slate-900)', color: '#fff', border: 'none', borderRadius: 8, fontSize: 12 }}/>
                </PieChart>
              </ResponsiveContainer>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8 }}>
                {categoryData.map((c, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                      <div style={{ width: 8, height: 8, borderRadius: 2, background: PIE_COLORS[i % PIE_COLORS.length] }}/>
                      <span style={{ fontSize: 12, color: 'var(--slate-600)' }}>{c.name}</span>
                    </div>
                    <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--slate-700)' }}>{settings.currencySymbol}{c.value.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div style={{ textAlign: 'center', color: 'var(--slate-400)', fontSize: 13, padding: '40px 0' }}>Sin ingresos registrados aún</div>
          )}
        </div>
      </div>

      {/* Charts row 2 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>

        {/* Top products bar */}
        <div style={{ ...card, padding: 24 }}>
          <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--slate-900)', marginBottom: 2 }}>Productos más Vendidos</p>
          <p style={{ fontSize: 12, color: 'var(--slate-500)', marginBottom: 20 }}>Por ingresos generados</p>
          {topProducts.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={topProducts} layout="vertical" barSize={14}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--surface-border)" horizontal={false}/>
                <XAxis type="number" tick={{ fontSize: 11, fill: 'var(--slate-400)' }} axisLine={false} tickLine={false} tickFormatter={v => `$${v/1000}k`}/>
                <YAxis dataKey="name" type="category" tick={{ fontSize: 11, fill: 'var(--slate-600)' }} axisLine={false} tickLine={false} width={110}/>
                <Tooltip content={<CustomTooltip />}/>
                <Bar dataKey="revenue" name="Ingresos" fill="#3b82f6" radius={[0,6,6,0]}/>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div style={{ textAlign: 'center', color: 'var(--slate-400)', fontSize: 13, padding: '40px 0' }}>Sin ventas registradas aún</div>
          )}
        </div>

        {/* Stock status pie */}
        <div style={{ ...card, padding: 24 }}>
          <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--slate-900)', marginBottom: 2 }}>Estado del Inventario</p>
          <p style={{ fontSize: 12, color: 'var(--slate-500)', marginBottom: 16 }}>{products.length} productos en total</p>
          {stockSummary.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={140}>
                <PieChart>
                  <Pie data={stockSummary} cx="50%" cy="50%" innerRadius={38} outerRadius={60} dataKey="value" paddingAngle={3}>
                    {stockSummary.map((s, i) => <Cell key={i} fill={s.color} stroke="none"/>)}
                  </Pie>
                  <Tooltip contentStyle={{ background: 'var(--slate-900)', color: '#fff', border: 'none', borderRadius: 8, fontSize: 12 }}/>
                </PieChart>
              </ResponsiveContainer>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 7, marginTop: 10 }}>
                {stockSummary.map((s, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                      <div style={{ width: 8, height: 8, borderRadius: 2, background: s.color }}/>
                      <span style={{ fontSize: 12, color: 'var(--slate-600)' }}>{s.name}</span>
                    </div>
                    <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--slate-700)' }}>{s.value} productos</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div style={{ textAlign: 'center', color: 'var(--slate-400)', fontSize: 13, padding: '40px 0' }}>Sin productos</div>
          )}
        </div>
      </div>

      {/* Recent transactions */}
      <div style={card}>
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--surface-border)' }}>
          <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--slate-900)', margin: 0 }}>Movimientos Recientes</p>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-bg)' }}>
                {['Fecha','Descripción','Categoría','Tipo','Monto'].map(h => (
                  <th key={h} style={{ textAlign: 'left', padding: '10px 20px', fontSize: 11.5, fontWeight: 600, color: 'var(--slate-500)', letterSpacing: '0.04em', textTransform: 'uppercase', borderBottom: '1px solid var(--surface-border)', whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {recentTx.map((t, i) => (
                <tr key={t.id}
                  style={{ borderBottom: i < recentTx.length - 1 ? '1px solid var(--surface-border)' : 'none', transition: 'background 0.12s' }}
                  onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface-hover)')}
                  onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                >
                  <td style={{ padding: '12px 20px', fontSize: 12.5, color: 'var(--slate-500)', whiteSpace: 'nowrap' }}>
                    {new Date(t.date + 'T12:00:00').toLocaleDateString('es-MX', { day: '2-digit', month: 'short', year: 'numeric' })}
                  </td>
                  <td style={{ padding: '12px 20px', fontSize: 13, fontWeight: 500, color: 'var(--slate-900)', maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.description}</td>
                  <td style={{ padding: '12px 20px' }}>
                    <span style={{ fontSize: 12, fontWeight: 500, color: '#64748b', background: '#f1f5f9', padding: '3px 9px', borderRadius: 999 }}>{t.category}</span>
                  </td>
                  <td style={{ padding: '12px 20px' }}>
                    <span style={{ fontSize: 12, fontWeight: 500, color: t.type === 'income' ? '#059669' : '#dc2626', background: t.type === 'income' ? '#ecfdf5' : '#fef2f2', padding: '3px 9px', borderRadius: 999 }}>
                      {t.type === 'income' ? 'Ingreso' : 'Gasto'}
                    </span>
                  </td>
                  <td style={{ padding: '12px 20px', fontSize: 14, fontWeight: 700, color: t.type === 'income' ? '#059669' : '#dc2626', letterSpacing: '-0.02em', whiteSpace: 'nowrap' }}>
                    {t.type === 'income' ? '+' : '−'}{settings.currencySymbol}{t.amount.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {recentTx.length === 0 && (
            <div style={{ padding: '50px 0', textAlign: 'center', color: 'var(--slate-400)', fontSize: 13 }}>Sin movimientos registrados</div>
          )}
        </div>
      </div>

    </div>
  );
}
