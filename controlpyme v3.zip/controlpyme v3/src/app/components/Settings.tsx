import { useEffect, useState } from 'react';
import { Save, CheckCircle, Building2, DollarSign, Bell, Shield, LogOut, Zap } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { TeamAccess } from './TeamAccess';

const card: React.CSSProperties = {
  background: 'var(--surface-card)',
  borderRadius: 'var(--radius-lg)',
  border: '1px solid var(--surface-border)',
  boxShadow: 'var(--shadow-sm)',
};

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '9px 12px',
  border: '1px solid var(--surface-border)',
  borderRadius: 8,
  fontSize: 13.5,
  color: 'var(--slate-900)',
  background: 'var(--surface-card)',
  outline: 'none',
  boxSizing: 'border-box',
  fontFamily: 'inherit',
  transition: 'border-color 0.15s',
};

const CURRENCIES = [
  { code: 'USD', symbol: '$',  label: 'Dólar estadounidense (USD)' },
  { code: 'COP', symbol: '$',  label: 'Peso colombiano (COP)'      },
  { code: 'MXN', symbol: '$',  label: 'Peso mexicano (MXN)'        },
  { code: 'EUR', symbol: '€',  label: 'Euro (EUR)'                 },
  { code: 'PEN', symbol: 'S/', label: 'Sol peruano (PEN)'          },
  { code: 'CLP', symbol: '$',  label: 'Peso chileno (CLP)'         },
  { code: 'ARS', symbol: '$',  label: 'Peso argentino (ARS)'       },
];

export function Settings() {
  const { settings, updateSettings, auth, logout, products, transactions, sales, can } = useApp();

  const [form, setForm]       = useState({ ...settings });
  const [saved, setSaved]     = useState(false);
  const [changed, setChanged] = useState(false);
  const [saveError, setSaveError] = useState('');

  useEffect(() => {
    setForm({ ...settings });
    setChanged(false);
  }, [auth.business?.id, settings]);

  const handleChange = (field: string, value: string | number) => {
    setForm(prev => ({ ...prev, [field]: value }));
    setChanged(true);
    setSaved(false);
  };

  const handleSave = async () => {
    // Sync currencySymbol when currency changes
    const cur = CURRENCIES.find(c => c.code === form.currency);
    const finalForm = { ...form, currencySymbol: cur?.symbol ?? form.currencySymbol };
    setSaveError('');
    try {
      await updateSettings(finalForm);
      setSaved(true);
      setChanged(false);
      setTimeout(() => setSaved(false), 2500);
    } catch (error) {
      setSaveError(error instanceof Error ? error.message : 'No se pudo guardar la configuración.');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 700, color: 'var(--slate-900)', letterSpacing: '-0.03em', margin: 0 }}>Configuración</h1>
          <p style={{ color: 'var(--slate-500)', fontSize: 13.5, marginTop: 4 }}>
            Personaliza {settings.businessName}
          </p>
        </div>
        {can('settings:update') && <button
          onClick={handleSave}
          disabled={!changed}
          style={{
            background: changed ? 'var(--blue-500)' : '#e2e8f0',
            color: changed ? '#fff' : 'var(--slate-400)',
            border: 'none', borderRadius: 'var(--radius-md)',
            padding: '9px 16px', fontSize: 13.5, fontWeight: 600,
            display: 'flex', alignItems: 'center', gap: 7,
            cursor: changed ? 'pointer' : 'not-allowed', fontFamily: 'inherit',
            transition: 'background 0.15s',
          }}
        >
          {saved ? <CheckCircle size={15} /> : <Save size={15} />}
          {saved ? 'Guardado' : 'Guardar cambios'}
        </button>}
      </div>
      {saveError && <p role="alert" style={{ color: 'var(--danger-text)', margin: 0 }}>{saveError}</p>}

      {/* User banner */}
      <div className="animate-fade-in" style={{
        background: 'linear-gradient(135deg, #1e3a8a 0%, #1d4ed8 100%)',
        borderRadius: 'var(--radius-lg)', padding: '20px 24px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        boxShadow: '0 4px 20px rgba(29,78,216,0.25)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 46, height: 46, borderRadius: 12, background: 'rgba(255,255,255,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Zap size={22} color="#fff" />
          </div>
          <div>
            <p style={{ color: '#fff', fontWeight: 700, fontSize: 15, margin: 0 }}>{auth.user?.name ?? 'Usuario'}</p>
            <p style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12.5, marginTop: 3 }}>{auth.user?.email}</p>
          </div>
        </div>
        <button onClick={logout} style={{ background: 'rgba(255,255,255,0.15)', color: '#fff', border: '1px solid rgba(255,255,255,0.2)', borderRadius: 8, padding: '8px 16px', fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, fontFamily: 'inherit' }}>
          <LogOut size={14} /> Cerrar sesión
        </button>
      </div>

      {/* Data stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 14 }}>
        {[
          { label: 'Productos registrados',    value: products.length,      color: '#3b82f6' },
          { label: 'Transacciones totales',    value: transactions.length,  color: '#10b981' },
          { label: 'Ventas realizadas',        value: sales.length,         color: '#8b5cf6' },
        ].map((s, i) => (
          <div key={i} style={{ ...card, padding: '16px 20px' }}>
            <p style={{ fontSize: 12, color: 'var(--slate-500)', fontWeight: 500, marginBottom: 4 }}>{s.label}</p>
            <p style={{ fontSize: 28, fontWeight: 700, color: s.color, letterSpacing: '-0.04em', margin: 0 }}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Business settings */}
      <div style={card}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '16px 20px', borderBottom: '1px solid var(--surface-border)' }}>
          <Building2 size={16} color="var(--slate-500)" />
          <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--slate-900)', margin: 0 }}>Información del Negocio</p>
        </div>
        <div style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 18 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Nombre del negocio</label>
              <input
                style={inputStyle} value={form.businessName}
                onChange={e => handleChange('businessName', e.target.value)}
                placeholder="Mi Empresa"
                onFocus={e => (e.target.style.borderColor = '#3b82f6')}
                onBlur={e => (e.target.style.borderColor = 'var(--surface-border)')}
              />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Nombre del propietario</label>
              <input
                style={inputStyle} value={form.ownerName}
                onChange={e => handleChange('ownerName', e.target.value)}
                placeholder="Nombre completo"
                onFocus={e => (e.target.style.borderColor = '#3b82f6')}
                onBlur={e => (e.target.style.borderColor = 'var(--surface-border)')}
              />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Correo electrónico</label>
              <input
                style={inputStyle} type="email" value={form.ownerEmail}
                onChange={e => handleChange('ownerEmail', e.target.value)}
                placeholder="correo@empresa.com"
                onFocus={e => (e.target.style.borderColor = '#3b82f6')}
                onBlur={e => (e.target.style.borderColor = 'var(--surface-border)')}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Currency settings */}
      <div style={card}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '16px 20px', borderBottom: '1px solid var(--surface-border)' }}>
          <DollarSign size={16} color="var(--slate-500)" />
          <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--slate-900)', margin: 0 }}>Moneda y Región</p>
        </div>
        <div style={{ padding: 24, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Moneda</label>
            <select
              style={{ ...inputStyle, cursor: 'pointer' }}
              value={form.currency}
              onChange={e => {
                const cur = CURRENCIES.find(c => c.code === e.target.value);
                setForm(prev => ({ ...prev, currency: e.target.value, currencySymbol: cur?.symbol ?? prev.currencySymbol }));
                setChanged(true); setSaved(false);
              }}
            >
              {CURRENCIES.map(c => <option key={c.code} value={c.code}>{c.label}</option>)}
            </select>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Símbolo de moneda</label>
            <input
              style={{ ...inputStyle, background: 'var(--surface-bg)', color: 'var(--slate-500)' }}
              value={CURRENCIES.find(c => c.code === form.currency)?.symbol ?? form.currencySymbol}
              readOnly
            />
          </div>
        </div>
      </div>

      {/* Stock threshold */}
      <div style={card}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '16px 20px', borderBottom: '1px solid var(--surface-border)' }}>
          <Bell size={16} color="var(--slate-500)" />
          <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--slate-900)', margin: 0 }}>Alertas de Inventario</p>
        </div>
        <div style={{ padding: 24 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, maxWidth: 320 }}>
            <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>
              Umbral de stock bajo (unidades)
            </label>
            <input
              type="number" min={1} max={100}
              style={inputStyle} value={form.lowStockThreshold}
              onChange={e => handleChange('lowStockThreshold', +e.target.value)}
              onFocus={e => (e.target.style.borderColor = '#3b82f6')}
              onBlur={e => (e.target.style.borderColor = 'var(--surface-border)')}
            />
            <p style={{ fontSize: 12, color: 'var(--slate-400)', marginTop: 2 }}>
              Los productos con stock igual o inferior a este valor se marcarán como "Bajo Stock".
            </p>
          </div>
        </div>
      </div>

      {/* System info */}
      <div style={card}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '16px 20px', borderBottom: '1px solid var(--surface-border)' }}>
          <Shield size={16} color="var(--slate-500)" />
          <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--slate-900)', margin: 0 }}>Información del Sistema</p>
        </div>
        <div style={{ padding: '4px 0' }}>
          {[
            { label: 'Versión',       value: 'v2.5.1',               type: 'text'  },
            { label: 'Tecnología',    value: 'React + TypeScript',    type: 'text'  },
            { label: 'Datos',         value: 'MySQL · negocio aislado', type: 'text'  },
            { label: 'Acceso',        value: auth.role ?? 'Usuario',   type: 'badge' },
          ].map((row, i, arr) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '13px 20px', borderBottom: i < arr.length - 1 ? '1px solid var(--surface-border)' : 'none' }}>
              <span style={{ fontSize: 13.5, color: 'var(--slate-600)' }}>{row.label}</span>
              {row.type === 'text' && <span style={{ fontSize: 13.5, fontWeight: 500, color: 'var(--slate-900)' }}>{row.value}</span>}
              {row.type === 'badge' && <span style={{ background: '#eff6ff', color: '#1d4ed8', padding: '4px 12px', borderRadius: 20, fontSize: 12.5, fontWeight: 600 }}>{row.value}</span>}
            </div>
          ))}
        </div>
      </div>

      {(can('roles:manage') || can('users:manage')) && <TeamAccess />}

      {/* Save confirmation toast */}
      {saved && (
        <div style={{
          position: 'fixed', bottom: 24, right: 24, zIndex: 2000,
          background: 'var(--tooltip-bg)', color: 'var(--tooltip-fg)', borderRadius: 12,
          padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 10,
          boxShadow: '0 8px 32px rgba(0,0,0,0.25)', fontSize: 13.5, fontWeight: 500,
        }}>
          <CheckCircle size={18} color="#10b981" />
          Configuración guardada correctamente
        </div>
      )}

    </div>
  );
}
