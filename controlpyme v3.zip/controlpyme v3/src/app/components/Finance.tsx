import { useState } from 'react';
import { DollarSign, TrendingUp, TrendingDown, Plus, Trash2, Edit2, CheckCircle, AlertCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import type { Transaction } from '../../context/AppContext';

// ─── Shared styles ────────────────────────────────────────────────────────────

const card: React.CSSProperties = {
  background: 'var(--surface-card)',
  borderRadius: 'var(--radius-lg)',
  border: '1px solid var(--surface-border)',
  boxShadow: 'var(--shadow-sm)',
};

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '9px 12px',
  border: '1px solid var(--surface-border)',
  borderRadius: 8,
  fontSize: 13.5,
  color: 'var(--slate-900)',
  background: 'var(--surface-card)',
  outline: 'none',
  boxSizing: 'border-box',
  fontFamily: 'inherit',
  transition: 'border-color 0.15s',
};

const STATUS_CONFIG = {
  'Completado': { bg: '#ecfdf5', color: '#065f46', dot: '#10b981' },
  'Pendiente':  { bg: '#fffbeb', color: '#92400e', dot: '#f59e0b' },
  'Cancelado':  { bg: '#fef2f2', color: '#991b1b', dot: '#ef4444' },
} as const;

const CAT_COLORS: Record<string, string> = {
  Ventas: '#3b82f6', Nómina: '#8b5cf6', Inventario: '#f59e0b',
  Marketing: '#10b981', Operaciones: '#94a3b8', Servicios: '#06b6d4',
  'Otro ingreso': '#22c55e', 'Otro gasto': '#f43f5e', Alquiler: '#a78bfa',
};

const CATS_INCOME  = ['Ventas', 'Servicios', 'Inversión', 'Otro ingreso'];
const CATS_EXPENSE = ['Nómina', 'Inventario', 'Marketing', 'Operaciones', 'Alquiler', 'Servicios', 'Otro gasto'];

// ─── Modal ────────────────────────────────────────────────────────────────────

interface ModalProps { open: boolean; onClose: () => void; title: string; children: React.ReactNode; width?: number; }

function Modal({ open, onClose, title, children, width = 520 }: ModalProps) {
  if (!open) return null;
  return (
    <div onClick={onClose} style={{ position: 'fixed', inset: 0, zIndex: 1000, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, backdropFilter: 'blur(2px)' }}>
      <div onClick={e => e.stopPropagation()} style={{ background: 'var(--surface-card)', borderRadius: 16, border: '1px solid var(--surface-border)', boxShadow: '0 20px 60px rgba(0,0,0,0.15)', width: '100%', maxWidth: width, maxHeight: '90vh', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 24px', borderBottom: '1px solid var(--surface-border)', flexShrink: 0 }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, color: 'var(--slate-900)', margin: 0 }}>{title}</h2>
          <button onClick={onClose} style={{ background: 'none', border: '1px solid var(--surface-border)', borderRadius: 7, padding: '5px 10px', cursor: 'pointer', fontSize: 13, color: 'var(--slate-500)', fontFamily: 'inherit' }}>✕</button>
        </div>
        <div style={{ padding: 24, overflowY: 'auto', flex: 1 }}>{children}</div>
      </div>
    </div>
  );
}

// ─── Form state ───────────────────────────────────────────────────────────────

type TxType   = 'income' | 'expense';
type TxStatus = 'Completado' | 'Pendiente' | 'Cancelado';

interface TxForm {
  description: string;
  category: string;
  amount: number;
  type: TxType;
  date: string;
  status: TxStatus;
}

const emptyForm = (type: TxType): TxForm => ({
  description: '',
  category: type === 'income' ? 'Ventas' : 'Nómina',
  amount: 0,
  type,
  date: new Date().toISOString().slice(0, 10),
  status: 'Completado',
});

// ─── Component ────────────────────────────────────────────────────────────────

export function Finance() {
  const { transactions, addTransaction, editTransaction, deleteTransaction, settings, can } = useApp();
  const mergedTxs = transactions;

  const [showModal, setShowModal]   = useState(false);
  const [editTarget, setEditTarget] = useState<Transaction | null>(null);
  const [form, setForm]             = useState<TxForm>(emptyForm('income'));
  const [formError, setFormError]   = useState('');
  const [success, setSuccess]       = useState('');
  const [deleteId, setDeleteId]     = useState<string | null>(null);
  const [typeFilter, setTypeFilter] = useState<'all' | TxType>('all');

  const openAdd = (type: TxType) => {
    setEditTarget(null);
    setForm(emptyForm(type));
    setFormError(''); setSuccess('');
    setShowModal(true);
  };

  const openEdit = (t: Transaction) => {
    setEditTarget(t);
    setForm({ description: t.description, category: t.category, amount: t.amount, type: t.type, date: t.date, status: t.status });
    setFormError(''); setSuccess('');
    setShowModal(true);
  };

  const handleSave = async () => {
    if (!form.description.trim()) { setFormError('La descripción es obligatoria.'); return; }
    if (form.amount <= 0)         { setFormError('El monto debe ser mayor a 0.'); return; }

    try {
      if (editTarget) await editTransaction(editTarget.id, form);
      else await addTransaction(form);
      setSuccess('Transacción guardada.');
      setTimeout(() => { setShowModal(false); setSuccess(''); }, 1200);
    } catch (error) {
      setFormError(error instanceof Error ? error.message : 'No se pudo guardar el movimiento.');
    }
  };

  const handleDelete = async () => {
    if (deleteId) {
      try {
        await deleteTransaction(deleteId);
        setDeleteId(null);
      } catch (error) {
        setFormError(error instanceof Error ? error.message : 'No se pudo eliminar el movimiento.');
        setDeleteId(null);
      }
    }
  };

  const displayed = typeFilter === 'all' ? mergedTxs : mergedTxs.filter(t => t.type === typeFilter);

  // Recompute totals from merged list
  const localIncome   = mergedTxs.filter(t => t.type === 'income' && t.status === 'Completado').reduce((s, t) => s + t.amount, 0);
  const localExpenses = mergedTxs.filter(t => t.type === 'expense' && t.status === 'Completado').reduce((s, t) => s + t.amount, 0);
  const localBalance  = localIncome - localExpenses;

  const fmt = (n: number) => n.toLocaleString('es-MX', { minimumFractionDigits: 2 });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 700, color: 'var(--slate-900)', letterSpacing: '-0.03em', margin: 0 }}>Finanzas</h1>
          <p style={{ color: 'var(--slate-500)', fontSize: 13.5, marginTop: 4 }}>Gestión de transacciones y flujo de caja</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          {can('finance:create') && <button onClick={() => openAdd('expense')} style={{ background: 'var(--surface-card)', color: '#dc2626', border: '1px solid #fecaca', borderRadius: 'var(--radius-md)', padding: '9px 14px', fontSize: 13.5, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 7, cursor: 'pointer', fontFamily: 'inherit' }}>
            <TrendingDown size={15} /> Gasto
          </button>}
          {can('finance:create') && <button onClick={() => openAdd('income')} style={{ background: 'var(--blue-500)', color: '#fff', border: 'none', borderRadius: 'var(--radius-md)', padding: '9px 16px', fontSize: 13.5, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 7, cursor: 'pointer', fontFamily: 'inherit' }}>
            <Plus size={15} /> Ingreso
          </button>}
        </div>
      </div>

      {/* Summary Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16 }}>
        {[
          { label: 'Ingresos Totales', value: `+${settings.currencySymbol}${fmt(localIncome)}`,   icon: TrendingUp,   accent: '#10b981', bg: '#ecfdf5' },
          { label: 'Gastos Totales',   value: `${settings.currencySymbol}${fmt(localExpenses)}`,   icon: TrendingDown, accent: '#ef4444', bg: '#fef2f2' },
          { label: 'Balance Neto',     value: `${localBalance >= 0 ? '+' : ''}${settings.currencySymbol}${fmt(localBalance)}`, icon: DollarSign, accent: localBalance >= 0 ? '#3b82f6' : '#f59e0b', bg: localBalance >= 0 ? '#eff6ff' : '#fffbeb' },
        ].map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className={`animate-fade-in stagger-${i + 1}`} style={{ ...card, padding: 20 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
                <div style={{ width: 40, height: 40, borderRadius: 10, background: s.bg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Icon size={18} color={s.accent} />
                </div>
                <span style={{ fontSize: 12.5, color: 'var(--slate-500)', fontWeight: 500 }}>{s.label}</span>
              </div>
              <p style={{ fontSize: 24, fontWeight: 700, color: s.accent, letterSpacing: '-0.03em', margin: 0 }}>{s.value}</p>
            </div>
          );
        })}
      </div>

      {/* Table */}
      <div className="animate-fade-in stagger-2" style={card}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 20px', borderBottom: '1px solid var(--surface-border)' }}>
          <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--slate-900)', margin: 0 }}>Transacciones</p>
          <div style={{ display: 'flex', gap: 6 }}>
            {(['all', 'income', 'expense'] as const).map(f => (
              <button key={f} onClick={() => setTypeFilter(f)} style={{
                padding: '5px 12px', borderRadius: 7, fontSize: 12.5, cursor: 'pointer', fontFamily: 'inherit',
                border: typeFilter === f ? 'none' : '1px solid var(--surface-border)',
                background: typeFilter === f ? 'var(--blue-500)' : '#fff',
                color: typeFilter === f ? '#fff' : 'var(--slate-600)',
                fontWeight: typeFilter === f ? 600 : 400,
              }}>
                {f === 'all' ? 'Todos' : f === 'income' ? 'Ingresos' : 'Gastos'}
              </button>
            ))}
          </div>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-bg)' }}>
                {['Fecha', 'Descripción', 'Categoría', 'Monto', 'Estado', ''].map(h => (
                  <th key={h} style={{ textAlign: 'left', padding: '11px 20px', fontSize: 11.5, fontWeight: 600, color: 'var(--slate-500)', letterSpacing: '0.04em', textTransform: 'uppercase', borderBottom: '1px solid var(--surface-border)', whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {displayed.map((t, i) => {
                const sc  = STATUS_CONFIG[t.status];
                const cc  = CAT_COLORS[t.category] ?? '#94a3b8';
                return (
                  <tr key={t.id}
                    style={{ borderBottom: i < displayed.length - 1 ? '1px solid var(--surface-border)' : 'none', transition: 'background 0.12s' }}
                    onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface-hover)')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                  >
                    <td style={{ padding: '13px 20px', fontSize: 12.5, color: 'var(--slate-500)', whiteSpace: 'nowrap' }}>
                      {new Date(t.date + 'T12:00:00').toLocaleDateString('es-MX', { day: '2-digit', month: 'short', year: 'numeric' })}
                    </td>
                    <td style={{ padding: '13px 20px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div style={{ width: 28, height: 28, borderRadius: 7, flexShrink: 0, background: t.type === 'income' ? '#ecfdf5' : '#fef2f2', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          {t.type === 'income' ? <TrendingUp size={13} color="#10b981" /> : <TrendingDown size={13} color="#ef4444" />}
                        </div>
                        <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--slate-800)' }}>{t.description}</span>
                      </div>
                    </td>
                    <td style={{ padding: '13px 20px' }}>
                      <span style={{ fontSize: 12, fontWeight: 500, color: cc, background: `${cc}18`, padding: '3px 9px', borderRadius: 999 }}>{t.category}</span>
                    </td>
                    <td style={{ padding: '13px 20px' }}>
                      <span style={{ fontSize: 14, fontWeight: 700, letterSpacing: '-0.02em', color: t.type === 'income' ? '#059669' : '#dc2626' }}>
                        {t.type === 'income' ? '+' : '−'}{settings.currencySymbol}{fmt(t.amount)}
                      </span>
                    </td>
                    <td style={{ padding: '13px 20px' }}>
                      <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: sc.bg, color: sc.color, padding: '4px 10px', borderRadius: 999 }}>
                        <div style={{ width: 6, height: 6, borderRadius: '50%', background: sc.dot }} />
                        <span style={{ fontSize: 12, fontWeight: 500 }}>{t.status}</span>
                      </div>
                    </td>
                    <td style={{ padding: '13px 20px' }}>
                      <div style={{ display: 'flex', gap: 6 }}>
                        {can('finance:update') && <button onClick={() => openEdit(t)} title="Editar" style={{ background: 'none', border: '1px solid var(--surface-border)', borderRadius: 6, padding: '5px 7px', cursor: 'pointer', color: 'var(--slate-600)', display: 'flex' }}>
                          <Edit2 size={12} />
                        </button>}
                        {can('finance:delete') && <button onClick={() => setDeleteId(t.id)} title="Eliminar" style={{ background: 'none', border: '1px solid #fecaca', borderRadius: 6, padding: '5px 7px', cursor: 'pointer', color: '#ef4444', display: 'flex' }}>
                          <Trash2 size={12} />
                        </button>}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {displayed.length === 0 && (
            <div style={{ padding: '60px 0', textAlign: 'center', color: 'var(--slate-400)', fontSize: 13 }}>
              Sin transacciones{typeFilter !== 'all' ? ` de ${typeFilter === 'income' ? 'ingresos' : 'gastos'}` : ''}.
            </div>
          )}
        </div>
      </div>

      {/* Add / Edit Modal */}
      <Modal open={showModal} onClose={() => setShowModal(false)} title={editTarget ? 'Editar Transacción' : `Registrar ${form.type === 'income' ? 'Ingreso' : 'Gasto'}`}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {formError && (
            <div style={{ background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 8, padding: '10px 14px', fontSize: 13, color: '#991b1b', display: 'flex', alignItems: 'center', gap: 8 }}>
              <AlertCircle size={14} /> {formError}
            </div>
          )}
          {success && (
            <div style={{ background: '#ecfdf5', border: '1px solid #86efac', borderRadius: 8, padding: '10px 14px', fontSize: 13, color: '#065f46', display: 'flex', alignItems: 'center', gap: 8 }}>
              <CheckCircle size={14} /> {success}
            </div>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>

            <div style={{ gridColumn: '1 / -1', display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Descripción *</label>
              <input style={inputStyle} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Ej: Venta a cliente ABC" onFocus={e => (e.target.style.borderColor = '#3b82f6')} onBlur={e => (e.target.style.borderColor = 'var(--surface-border)')} />
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Tipo</label>
              <select style={{ ...inputStyle, cursor: 'pointer' }} value={form.type} onChange={e => { const t = e.target.value as TxType; setForm({ ...form, type: t, category: t === 'income' ? 'Ventas' : 'Nómina' }); }}>
                <option value="income">Ingreso</option>
                <option value="expense">Gasto</option>
              </select>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Categoría</label>
              <select style={{ ...inputStyle, cursor: 'pointer' }} value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
                {(form.type === 'income' ? CATS_INCOME : CATS_EXPENSE).map(c => <option key={c}>{c}</option>)}
              </select>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Monto ({settings.currencySymbol}) *</label>
              <input type="number" min={0} step={0.01} style={inputStyle} value={form.amount} onChange={e => setForm({ ...form, amount: +e.target.value })} onFocus={e => (e.target.style.borderColor = '#3b82f6')} onBlur={e => (e.target.style.borderColor = 'var(--surface-border)')} />
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Fecha</label>
              <input type="date" style={inputStyle} value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} onFocus={e => (e.target.style.borderColor = '#3b82f6')} onBlur={e => (e.target.style.borderColor = 'var(--surface-border)')} />
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--slate-700)' }}>Estado</label>
              <select style={{ ...inputStyle, cursor: 'pointer' }} value={form.status} onChange={e => setForm({ ...form, status: e.target.value as TxStatus })}>
                <option value="Completado">Completado</option>
                <option value="Pendiente">Pendiente</option>
                <option value="Cancelado">Cancelado</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 4 }}>
            <button onClick={() => setShowModal(false)} style={{ padding: '9px 18px', border: '1px solid var(--surface-border)', borderRadius: 8, background: 'var(--surface-card)', color: 'var(--slate-700)', fontSize: 13.5, cursor: 'pointer', fontFamily: 'inherit' }}>Cancelar</button>
            <button onClick={handleSave} style={{ padding: '9px 18px', border: 'none', borderRadius: 8, background: form.type === 'income' ? 'var(--blue-500)' : '#dc2626', color: '#fff', fontSize: 13.5, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 7, fontFamily: 'inherit' }}>
              {form.type === 'income' ? <TrendingUp size={15} /> : <TrendingDown size={15} />}
              {editTarget ? 'Guardar cambios' : `Registrar ${form.type === 'income' ? 'ingreso' : 'gasto'}`}
            </button>
          </div>
        </div>
      </Modal>

      {/* Delete confirm */}
      <Modal open={!!deleteId} onClose={() => setDeleteId(null)} title="Eliminar transacción" width={400}>
        <p style={{ fontSize: 14, color: 'var(--slate-700)', marginBottom: 20, lineHeight: 1.5 }}>
          ¿Eliminar esta transacción? Esta acción <strong>no se puede deshacer</strong>.
        </p>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
          <button onClick={() => setDeleteId(null)} style={{ padding: '9px 18px', border: '1px solid var(--surface-border)', borderRadius: 8, background: 'var(--surface-card)', color: 'var(--slate-700)', fontSize: 13.5, cursor: 'pointer', fontFamily: 'inherit' }}>Cancelar</button>
          <button onClick={handleDelete} style={{ padding: '9px 18px', border: 'none', borderRadius: 8, background: '#ef4444', color: '#fff', fontSize: 13.5, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>Sí, eliminar</button>
        </div>
      </Modal>

    </div>
  );
}
