import {
  DollarSign, Package, TrendingUp, ShoppingCart,
  AlertTriangle, AlertCircle, ArrowUpRight, ArrowDownRight,
} from 'lucide-react';
import {
  BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';
import { useApp } from '../../context/AppContext';

// ─── Shared styles ────────────────────────────────────────────────────────────

const card: React.CSSProperties = {
  background: 'var(--surface-card)',
  borderRadius: 'var(--radius-lg)',
  border: '1px solid var(--surface-border)',
  boxShadow: 'var(--shadow-sm)',
  padding: 24,
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: 'var(--tooltip-bg)', color: 'var(--tooltip-fg)',
      padding: '10px 14px', borderRadius: 10, fontSize: 12,
      boxShadow: 'var(--shadow-xl)',
      border: '1px solid var(--surface-border)',
    }}>
      <p style={{ color: 'var(--text-muted)', fontSize: 11, marginBottom: 4 }}>{label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} style={{ color: p.color ?? 'var(--tooltip-fg)', marginBottom: 2, fontWeight: 500 }}>
          {p.name}: <strong>${p.value?.toLocaleString()}</strong>
        </p>
      ))}
    </div>
  );
};

// ─── Component ────────────────────────────────────────────────────────────────

export function Dashboard() {
  const {
    products, transactions, sales,
    totalIncome, totalExpenses, balance,
    lowStockCount, outOfStockCount,
    settings,
  } = useApp();

  const fmt = (n: number) =>
    n.toLocaleString('es-MX', { minimumFractionDigits: 0, maximumFractionDigits: 0 });

  // ── KPI cards ──────────────────────────────────────────────────────────────
  const stats = [
    {
      title: 'Ingresos Totales',
      value: `${settings.currencySymbol}${fmt(totalIncome)}`,
      sub: `${transactions.filter(t => t.type === 'income').length} transacciones`,
      trend: 'up' as const,
      icon: DollarSign, accent: '#10b981', bg: '#ecfdf5', iconColor: '#10b981',
    },
    {
      title: 'Gastos Totales',
      value: `${settings.currencySymbol}${fmt(totalExpenses)}`,
      sub: `${transactions.filter(t => t.type === 'expense').length} transacciones`,
      trend: 'down' as const,
      icon: TrendingUp, accent: '#ef4444', bg: '#fef2f2', iconColor: '#ef4444',
    },
    {
      title: 'Balance Neto',
      value: `${settings.currencySymbol}${fmt(Math.abs(balance))}`,
      sub: balance >= 0 ? 'Saldo positivo' : 'Saldo negativo',
      trend: balance >= 0 ? 'up' as const : 'down' as const,
      icon: DollarSign,
      accent: balance >= 0 ? '#3b82f6' : '#f59e0b',
      bg: balance >= 0 ? '#eff6ff' : '#fffbeb',
      iconColor: balance >= 0 ? '#3b82f6' : '#f59e0b',
    },
    {
      title: 'Total Productos',
      value: products.length.toString(),
      sub: `${products.reduce((s, p) => s + p.stock, 0)} unidades en stock`,
      trend: 'up' as const,
      icon: Package, accent: '#8b5cf6', bg: '#f5f3ff', iconColor: '#8b5cf6',
    },
    {
      title: 'Ventas Realizadas',
      value: sales.length.toString(),
      sub: `${settings.currencySymbol}${fmt(sales.reduce((s, v) => s + v.total, 0))} en ingresos`,
      trend: 'up' as const,
      icon: ShoppingCart, accent: '#06b6d4', bg: '#ecfeff', iconColor: '#06b6d4',
    },
  ];

  // ── Monthly chart: group transactions by month ─────────────────────────────
  const MONTHS = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
  const now = new Date();
  const monthlyData = Array.from({ length: 6 }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - 5 + i, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const ingresos = transactions
      .filter(t => t.type === 'income' && t.date.startsWith(key))
      .reduce((s, t) => s + t.amount, 0);
    const gastos = transactions
      .filter(t => t.type === 'expense' && t.date.startsWith(key))
      .reduce((s, t) => s + t.amount, 0);
    return { month: MONTHS[d.getMonth()], ingresos, gastos };
  });

  // ── Recent activity: last 6 transactions ──────────────────────────────────
  const recentTx = [...transactions].slice(0, 6);

  // ── Stock alerts ──────────────────────────────────────────────────────────
  const lowProducts = products.filter(p => p.status === 'Bajo Stock').map(p => p.name);
  const outProducts = products.filter(p => p.status === 'Agotado').map(p => p.name);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>

      {/* Header */}
      <div>
        <h1 style={{ fontSize: 24, fontWeight: 700, color: 'var(--slate-900)', letterSpacing: '-0.03em', margin: 0 }}>
          Dashboard
        </h1>
        <p style={{ color: 'var(--slate-500)', fontSize: 13.5, marginTop: 4 }}>
          {settings.businessName} · {now.toLocaleDateString('es-MX', { month: 'long', year: 'numeric' })}
        </p>
      </div>

      {/* Stock alerts */}
      {(outOfStockCount > 0 || lowStockCount > 0) && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {outOfStockCount > 0 && (
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10, padding: '11px 16px', borderRadius: 'var(--radius-md)', background: '#fef2f2', border: '1px solid #fecaca' }}>
              <AlertCircle size={16} color="#ef4444" style={{ marginTop: 1, flexShrink: 0 }} />
              <span style={{ fontSize: 13, color: '#991b1b', fontWeight: 500 }}>
                <strong>{outOfStockCount} producto{outOfStockCount > 1 ? 's' : ''} agotado{outOfStockCount > 1 ? 's' : ''}:</strong>{' '}
                {outProducts.join(', ')}
              </span>
            </div>
          )}
          {lowStockCount > 0 && (
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10, padding: '11px 16px', borderRadius: 'var(--radius-md)', background: '#fffbeb', border: '1px solid #fde68a' }}>
              <AlertTriangle size={16} color="#f59e0b" style={{ marginTop: 1, flexShrink: 0 }} />
              <span style={{ fontSize: 13, color: '#92400e', fontWeight: 500 }}>
                <strong>{lowStockCount} producto{lowStockCount > 1 ? 's' : ''} con stock bajo:</strong>{' '}
                {lowProducts.join(', ')}
              </span>
            </div>
          )}
        </div>
      )}

      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16 }}>
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div key={i} className={`animate-fade-in stagger-${Math.min(i + 1, 4)}`} style={{
              ...card, padding: 20,
              display: 'flex', flexDirection: 'column', gap: 14,
            }}>
              <div style={{ width: 40, height: 40, borderRadius: 10, background: stat.bg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon size={18} color={stat.iconColor} />
              </div>
              <div>
                <p style={{ fontSize: 12, color: 'var(--slate-500)', fontWeight: 500, marginBottom: 4 }}>{stat.title}</p>
                <p style={{ fontSize: 22, fontWeight: 700, color: 'var(--slate-900)', letterSpacing: '-0.03em', lineHeight: 1, margin: 0 }}>{stat.value}</p>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                {stat.trend === 'up'
                  ? <ArrowUpRight size={13} color="#10b981" />
                  : <ArrowDownRight size={13} color="#ef4444" />}
                <span style={{ fontSize: 11.5, color: 'var(--slate-400)' }}>{stat.sub}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts Row */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 320px), 1fr))',
          gap: 16,
          alignItems: 'stretch',
        }}
      >

        {/* Bar Chart — real data */}
        <div className="animate-fade-in stagger-2" style={card}>
          <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--slate-900)', marginBottom: 2 }}>Ingresos vs Gastos</p>
          <p style={{ fontSize: 12, color: 'var(--slate-500)', marginBottom: 20 }}>Últimos 6 meses · {settings.currency}</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={monthlyData} barGap={4}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--surface-border)" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: 'var(--slate-500)' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: 'var(--slate-400)' }} axisLine={false} tickLine={false} tickFormatter={v => v > 0 ? `$${v / 1000}k` : '0'} />
              <Tooltip content={<CustomTooltip />} cursor={{ fill: 'var(--surface-hover)' }} />
              <Bar dataKey="ingresos" name="Ingresos" fill="#3b82f6" radius={[6, 6, 0, 0]} maxBarSize={28} />
              <Bar dataKey="gastos"   name="Gastos"   fill="#ef4444" radius={[6, 6, 0, 0]} maxBarSize={28} fillOpacity={0.75} />
            </BarChart>
          </ResponsiveContainer>
          <div style={{ display: 'flex', gap: 20, marginTop: 12 }}>
            {[['#3b82f6', 'Ingresos'], ['#ef4444', 'Gastos']].map(([c, l]) => (
              <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <div style={{ width: 10, height: 10, borderRadius: 3, background: c }} />
                <span style={{ fontSize: 12, color: 'var(--slate-500)' }}>{l}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Activity Feed — real transactions */}
        <div className="animate-fade-in stagger-3" style={card}>
          <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--slate-900)', marginBottom: 16 }}>Actividad reciente</p>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {recentTx.length === 0 && (
              <p style={{ fontSize: 12.5, color: 'var(--slate-400)', textAlign: 'center', padding: '24px 0' }}>
                Sin movimientos registrados
              </p>
            )}
            {recentTx.map((t, i) => (
              <div key={t.id} style={{
                display: 'flex', alignItems: 'flex-start', gap: 10,
                padding: '9px 0',
                borderBottom: i < recentTx.length - 1 ? '1px solid var(--surface-border)' : 'none',
              }}>
                <div style={{
                  width: 8, height: 8, borderRadius: '50%', marginTop: 5, flexShrink: 0,
                  background: t.type === 'income' ? '#10b981' : '#ef4444',
                }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ fontSize: 12.5, color: 'var(--slate-800)', fontWeight: 500, lineHeight: 1.3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {t.description}
                  </p>
                  <p style={{ fontSize: 11, color: 'var(--slate-400)', marginTop: 2 }}>
                    {new Date(t.date + 'T12:00:00').toLocaleDateString('es-MX', { day: '2-digit', month: 'short' })}
                  </p>
                </div>
                <span style={{ fontSize: 12, fontWeight: 600, whiteSpace: 'nowrap', color: t.type === 'income' ? '#10b981' : '#ef4444' }}>
                  {t.type === 'income' ? '+' : '−'}{settings.currencySymbol}{t.amount.toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Trend line */}
      <div className="animate-fade-in stagger-4" style={card}>
        <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--slate-900)', marginBottom: 2 }}>Tendencia de Ingresos</p>
        <p style={{ fontSize: 12, color: 'var(--slate-500)', marginBottom: 20 }}>Progresión mensual</p>
        <ResponsiveContainer width="100%" height={160}>
          <LineChart data={monthlyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--surface-border)" vertical={false} />
            <XAxis dataKey="month" tick={{ fontSize: 12, fill: 'var(--slate-500)' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: 'var(--slate-400)' }} axisLine={false} tickLine={false} tickFormatter={v => v > 0 ? `$${v / 1000}k` : '0'} />
            <Tooltip content={<CustomTooltip />} />
            <Line
              type="monotone" dataKey="ingresos" name="Ingresos"
              stroke="#3b82f6" strokeWidth={2.5}
              dot={{ fill: '#3b82f6', r: 4, strokeWidth: 0 }}
              activeDot={{ r: 6, fill: '#3b82f6', strokeWidth: 0 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

    </div>
  );
}
