import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Login } from './components/Login';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { Inventory } from './components/Inventory';
import { Sales } from './components/Sales';
import { Finance } from './components/Finance';
import { Reports } from './components/Reports';
import { Settings } from './components/Settings';

export default function App() {
  const { auth, authReady, can } = useApp();
  const [activeSection, setActiveSection] = useState('dashboard');

  if (!authReady) {
    return <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', color: 'var(--text-secondary)' }}>Conectando con ControlPyme…</div>;
  }

  if (!auth.isLoggedIn) {
    return <Login />;
  }

  const renderSection = () => {
    switch (activeSection) {
      case 'dashboard': return <Dashboard />;
      case 'inventory': return can('products:read') ? <Inventory /> : <Dashboard />;
      case 'sales':     return can('sales:read') ? <Sales /> : <Dashboard />;
      case 'finance':   return can('finance:read') ? <Finance /> : <Dashboard />;
      case 'reports':   return can('reports:read') ? <Reports /> : <Dashboard />;
      case 'settings':  return can('settings:read') ? <Settings /> : <Dashboard />;
      default:          return <Dashboard />;
    }
  };

  return (
    <div
      style={{
        display: 'flex',
        height: '100vh',
        width: '100%',
        background: 'var(--surface-bg)',
        overflow: 'hidden',
      }}
    >
      <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
      <main
        style={{
          flex: 1,
          overflowY: 'auto',
          overflowX: 'hidden',
          minWidth: 0,
        }}
      >
        <div
          className="animate-fade-in cp-shell-inner"
          style={{
            width: '100%',
            maxWidth: 1400,
            margin: '0 auto',
            padding: 'clamp(16px, 3vw, 32px)',
          }}
        >
          {renderSection()}
        </div>
      </main>
    </div>
  );
}
