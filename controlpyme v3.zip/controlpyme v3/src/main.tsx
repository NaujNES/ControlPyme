import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';

// Design tokens MUST load before any component-level CSS so that
// `var(--brand-500)`, `var(--surface-bg)`, `var(--gradient-sidebar)`, etc.
// resolve. Without this import the whole app renders with broken styles.
import './styles/globals.css';
import './index.css';

import App from './app/App';
import { AppProvider } from './context/AppContext';
import { ThemeProvider } from './context/ThemeContext';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ThemeProvider>
      <AppProvider>
        <App />
      </AppProvider>
    </ThemeProvider>
  </StrictMode>,
);
