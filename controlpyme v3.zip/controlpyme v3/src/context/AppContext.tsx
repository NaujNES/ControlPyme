import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { ReactNode } from 'react';

export interface Product {
  id: string; name: string; sku: string; category: string; stock: number;
  purchasePrice: number; salePrice: number; status: 'En Stock' | 'Bajo Stock' | 'Agotado';
}
export interface Transaction {
  id: string; date: string; description: string; category: string; amount: number;
  type: 'income' | 'expense'; status: 'Completado' | 'Pendiente' | 'Cancelado';
}
export interface Sale {
  id: string; date: string; productId: string; productName: string;
  quantity: number; unitPrice: number; total: number;
}
export interface AppSettings {
  businessName: string; currency: string; currencySymbol: string;
  lowStockThreshold: number; ownerName: string; ownerEmail: string;
}
export interface BusinessMembership {
  id: string; name: string; roleId: string; roleName: string;
}
export interface AuthState {
  isLoggedIn: boolean;
  user: { id: string; name: string; email: string } | null;
  business: { id: string; name: string } | null;
  role: string | null;
  permissions: string[];
  businesses: BusinessMembership[];
}

const emptyAuth: AuthState = { isLoggedIn: false, user: null, business: null, role: null, permissions: [], businesses: [] };
const defaults: AppSettings = {
  businessName: 'Mi Empresa', currency: 'COP', currencySymbol: '$',
  lowStockThreshold: 10, ownerName: '', ownerEmail: '',
};

export async function apiRequest<T = void>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  if (init.body && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  const response = await fetch(`/api${path}`, { ...init, headers, credentials: 'include' });
  if (response.status === 204) return undefined as T;
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || 'No se pudo completar la operación.');
  return payload as T;
}

interface AuthPayload extends Omit<AuthState, 'isLoggedIn'> {}

interface AppContextType {
  auth: AuthState;
  authReady: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  registerBusiness: (input: { businessName: string; name: string; email: string; password: string }) => Promise<boolean>;
  logout: () => Promise<void>;
  selectBusiness: (businessId: string) => Promise<void>;
  can: (permission: string) => boolean;
  products: Product[];
  addProduct: (p: Omit<Product, 'id' | 'status'>) => Promise<void>;
  editProduct: (id: string, updates: Partial<Omit<Product, 'id'>>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  transactions: Transaction[];
  addTransaction: (t: Omit<Transaction, 'id'>) => Promise<void>;
  editTransaction: (id: string, updates: Omit<Transaction, 'id'>) => Promise<void>;
  deleteTransaction: (id: string) => Promise<void>;
  sales: Sale[];
  addSale: (productId: string, quantity: number) => Promise<boolean>;
  settings: AppSettings;
  updateSettings: (updates: Partial<AppSettings>) => Promise<void>;
  totalIncome: number; totalExpenses: number; balance: number;
  lowStockCount: number; outOfStockCount: number;
}

const AppContext = createContext<AppContextType | null>(null);

function fromServer(payload: AuthPayload): AuthState {
  return { isLoggedIn: true, ...payload };
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [auth, setAuth] = useState<AuthState>(emptyAuth);
  const [authReady, setAuthReady] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [settings, setSettings] = useState<AppSettings>(defaults);

  const refreshSession = useCallback(async () => {
    const payload = await apiRequest<AuthPayload>('/auth/me');
    const nextAuth = fromServer(payload);
    setAuth(nextAuth);
    return nextAuth;
  }, []);

  const refreshData = useCallback(async () => {
    const allowed = (permission: string) => auth.role === 'Propietario'
      || auth.permissions.includes(permission)
      || (permission.endsWith(':read') && auth.permissions.includes('reports:read'));
    const [nextProducts, nextTransactions, nextSales, nextSettings] = await Promise.all([
      allowed('products:read') ? apiRequest<Product[]>('/products') : Promise.resolve([] as Product[]),
      allowed('finance:read') ? apiRequest<Transaction[]>('/transactions') : Promise.resolve([] as Transaction[]),
      allowed('sales:read') ? apiRequest<Sale[]>('/sales') : Promise.resolve([] as Sale[]),
      allowed('settings:read') ? apiRequest<Record<string, string>>('/settings') : Promise.resolve({} as Record<string, string>),
    ]);
    setProducts(nextProducts);
    setTransactions(nextTransactions);
    setSales(nextSales);
    setSettings({
      businessName: nextSettings.businessName || auth.business?.name || defaults.businessName,
      currency: nextSettings.currency || defaults.currency,
      currencySymbol: nextSettings.currencySymbol || defaults.currencySymbol,
      lowStockThreshold: Number(nextSettings.lowStockThreshold ?? defaults.lowStockThreshold),
      ownerName: nextSettings.ownerName || auth.user?.name || defaults.ownerName,
      ownerEmail: nextSettings.ownerEmail || auth.user?.email || defaults.ownerEmail,
    });
  }, [auth.business?.name, auth.permissions, auth.role, auth.user?.email, auth.user?.name]);

  useEffect(() => {
    let alive = true;
    apiRequest<AuthPayload>('/auth/me')
      .then(payload => { if (alive) setAuth(fromServer(payload)); })
      .catch(() => { if (alive) setAuth(emptyAuth); })
      .finally(() => { if (alive) setAuthReady(true); });
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    if (!auth.isLoggedIn) {
      setProducts([]); setTransactions([]); setSales([]); setSettings(defaults);
      return;
    }
    refreshData().catch(error => console.error('No se pudieron cargar los datos del negocio', error));
  }, [auth.isLoggedIn, auth.business?.id, refreshData]);

  const login = async (email: string, password: string) => {
    try {
      await apiRequest('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
      await refreshSession();
      return true;
    } catch { return false; }
  };

  const registerBusiness = async (input: { businessName: string; name: string; email: string; password: string }) => {
    try {
      await apiRequest('/auth/register', { method: 'POST', body: JSON.stringify(input) });
      await refreshSession();
      return true;
    } catch { return false; }
  };

  const logout = async () => {
    try { await apiRequest('/auth/logout', { method: 'POST' }); }
    finally { setAuth(emptyAuth); }
  };

  const selectBusiness = async (businessId: string) => {
    await apiRequest('/auth/select-business', { method: 'POST', body: JSON.stringify({ businessId }) });
    await refreshSession();
  };

  const can = (permission: string) => auth.role === 'Propietario' || auth.permissions.includes(permission);

  const addProduct = async (product: Omit<Product, 'id' | 'status'>) => {
    await apiRequest('/products', { method: 'POST', body: JSON.stringify(product) });
    await refreshData();
  };
  const editProduct = async (id: string, updates: Partial<Omit<Product, 'id'>>) => {
    const product = products.find(item => item.id === id);
    if (!product) throw new Error('No se encontró el producto.');
    await apiRequest(`/products/${id}`, { method: 'PUT', body: JSON.stringify({ ...product, ...updates }) });
    await refreshData();
  };
  const deleteProduct = async (id: string) => {
    await apiRequest(`/products/${id}`, { method: 'DELETE' });
    await refreshData();
  };
  const addTransaction = async (transaction: Omit<Transaction, 'id'>) => {
    await apiRequest('/transactions', { method: 'POST', body: JSON.stringify(transaction) });
    await refreshData();
  };
  const editTransaction = async (id: string, updates: Omit<Transaction, 'id'>) => {
    await apiRequest(`/transactions/${id}`, { method: 'PUT', body: JSON.stringify(updates) });
    await refreshData();
  };
  const deleteTransaction = async (id: string) => {
    await apiRequest(`/transactions/${id}`, { method: 'DELETE' });
    await refreshData();
  };
  const addSale = async (productId: string, quantity: number) => {
    await apiRequest('/sales', { method: 'POST', body: JSON.stringify({ productId, quantity }) });
    await refreshData();
    return true;
  };
  const updateSettings = async (updates: Partial<AppSettings>) => {
    await apiRequest('/settings', { method: 'PUT', body: JSON.stringify(updates) });
    await refreshData();
  };

  const totalIncome = transactions.filter(t => t.type === 'income' && t.status === 'Completado').reduce((sum, t) => sum + t.amount, 0);
  const totalExpenses = transactions.filter(t => t.type === 'expense' && t.status === 'Completado').reduce((sum, t) => sum + t.amount, 0);
  const lowStockCount = products.filter(product => product.status === 'Bajo Stock').length;
  const outOfStockCount = products.filter(product => product.status === 'Agotado').length;

  return <AppContext.Provider value={{
    auth, authReady, login, registerBusiness, logout, selectBusiness, can,
    products, addProduct, editProduct, deleteProduct,
    transactions, addTransaction, editTransaction, deleteTransaction,
    sales, addSale, settings, updateSettings,
    totalIncome, totalExpenses, balance: totalIncome - totalExpenses, lowStockCount, outOfStockCount,
  }}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}
