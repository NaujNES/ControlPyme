const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const crypto = require('crypto');
const { promisify } = require('util');
const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');

const app = express();
const PORT = Number(process.env.PORT) || 3001;
const DB_NAME = process.env.DB_NAME || 'controlpyme';
const COOKIE_NAME = 'cp_session';
const SESSION_DAYS = 7;
const SESSION_MS = SESSION_DAYS * 24 * 60 * 60 * 1000;
const hashPassword = promisify(crypto.scrypt);
const isProduction = process.env.NODE_ENV === 'production';
const allowedOrigins = new Set((process.env.FRONTEND_ORIGINS || 'http://localhost:5173,http://127.0.0.1:5173')
  .split(',').map(value => value.trim()).filter(Boolean));

if (!/^[a-zA-Z0-9_]+$/.test(DB_NAME)) {
  throw new Error('DB_NAME solo puede contener letras, números y guion bajo.');
}

app.use(cors({
  origin(origin, callback) {
    if (!origin || allowedOrigins.has(origin)) return callback(null, origin || false);
    return callback(new Error('Origen no permitido'));
  },
  credentials: true,
}));
app.use(express.json({ limit: '100kb' }));

const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD ?? '',
  waitForConnections: true,
  connectionLimit: 10,
  decimalNumbers: true,
  dateStrings: true,
  charset: 'utf8mb4',
};

const PERMISSIONS = [
  { key: 'products:read', label: 'Consultar inventario' },
  { key: 'products:create', label: 'Crear productos' },
  { key: 'products:update', label: 'Editar productos' },
  { key: 'products:delete', label: 'Eliminar productos' },
  { key: 'sales:read', label: 'Consultar ventas' },
  { key: 'sales:create', label: 'Registrar ventas' },
  { key: 'finance:read', label: 'Consultar finanzas' },
  { key: 'finance:create', label: 'Crear movimientos financieros' },
  { key: 'finance:update', label: 'Editar movimientos financieros' },
  { key: 'finance:delete', label: 'Eliminar movimientos financieros' },
  { key: 'reports:read', label: 'Consultar reportes' },
  { key: 'settings:read', label: 'Consultar configuración' },
  { key: 'settings:update', label: 'Editar configuración' },
  { key: 'users:manage', label: 'Administrar usuarios' },
  { key: 'roles:manage', label: 'Administrar roles y permisos' },
];
const PERMISSION_KEYS = new Set(PERMISSIONS.map(permission => permission.key));

const db = mysql.createPool({ ...dbConfig, database: DB_NAME });

function fail(res, status, message) {
  return res.status(status).json({ error: message });
}

function parseCookies(header = '') {
  return Object.fromEntries(header.split(';').map(part => {
    const index = part.indexOf('=');
    return index < 0 ? ['', ''] : [part.slice(0, index).trim(), decodeURIComponent(part.slice(index + 1).trim())];
  }).filter(([key]) => key));
}

function setSessionCookie(res, token) {
  const attributes = [
    `${COOKIE_NAME}=${encodeURIComponent(token)}`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    `Max-Age=${Math.floor(SESSION_MS / 1000)}`,
  ];
  if (isProduction) attributes.push('Secure');
  res.setHeader('Set-Cookie', attributes.join('; '));
}

function clearSessionCookie(res) {
  const attributes = [`${COOKIE_NAME}=`, 'Path=/', 'HttpOnly', 'SameSite=Lax', 'Max-Age=0'];
  if (isProduction) attributes.push('Secure');
  res.setHeader('Set-Cookie', attributes.join('; '));
}

function createToken() {
  return crypto.randomBytes(32).toString('base64url');
}

function tokenHash(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

async function saveSession(connection, userId, businessId) {
  const token = createToken();
  await connection.query(
    'INSERT INTO sessions (id, user_id, business_id, token_hash, expires_at) VALUES (?, ?, ?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? DAY))',
    [crypto.randomUUID(), userId, businessId, tokenHash(token), SESSION_DAYS]
  );
  return token;
}

async function getTenantSettings(businessId) {
  const [rows] = await db.query('SELECT `key`, `value` FROM settings WHERE business_id = ?', [businessId]);
  return Object.fromEntries(rows.map(row => [row.key, row.value]));
}

async function getMemberships(userId) {
  const [rows] = await db.query(
    `SELECT b.id, b.name, m.role_id AS roleId, r.name AS roleName
       FROM business_memberships m
       JOIN businesses b ON b.id = m.business_id
       JOIN roles r ON r.id = m.role_id
      WHERE m.user_id = ? AND m.is_active = 1 ORDER BY b.name`,
    [userId]
  );
  return rows;
}

async function loadSession(req, res, next) {
  try {
    const token = parseCookies(req.headers.cookie)[COOKIE_NAME];
    if (!token) return fail(res, 401, 'Inicia sesión para continuar.');
    const [rows] = await db.query(
      `SELECT s.id AS sessionId, s.user_id AS userId, s.business_id AS businessId,
              u.name, u.email, m.role_id AS roleId, r.name AS roleName
         FROM sessions s
         JOIN users u ON u.id = s.user_id AND u.is_active = 1
         JOIN business_memberships m ON m.user_id = u.id AND m.business_id = s.business_id AND m.is_active = 1
         JOIN roles r ON r.id = m.role_id AND r.business_id = m.business_id
        WHERE s.token_hash = ? AND s.expires_at > UTC_TIMESTAMP() LIMIT 1`,
      [tokenHash(token)]
    );
    if (!rows.length) {
      clearSessionCookie(res);
      return fail(res, 401, 'Tu sesión venció. Inicia sesión de nuevo.');
    }
    const session = rows[0];
    const [permissionRows] = await db.query(
      'SELECT permission_key FROM role_permissions WHERE role_id = ?', [session.roleId]
    );
    req.auth = {
      ...session,
      permissions: new Set(permissionRows.map(row => row.permission_key)),
    };
    return next();
  } catch (err) {
    return next(err);
  }
}

function requirePermission(permission) {
  return (req, res, next) => {
    if (req.auth.roleName === 'Propietario') return next();
    const reportRead = permission.endsWith(':read') && req.auth.permissions.has('reports:read');
    if (!req.auth.permissions.has(permission) && !reportRead) return fail(res, 403, 'No tienes permiso para realizar esta acción.');
    return next();
  };
}

function requireAnyPermission(...permissions) {
  return (req, res, next) => {
    if (req.auth.roleName === 'Propietario' || permissions.some(permission => req.auth.permissions.has(permission))) return next();
    return fail(res, 403, 'No tienes permiso para realizar esta acción.');
  };
}

function requireAllowedOrigin(req, res, next) {
  const origin = req.headers.origin;
  if (origin && !allowedOrigins.has(origin)) return fail(res, 403, 'Origen no permitido.');
  return next();
}

function validText(value, max = 255) {
  return typeof value === 'string' && value.trim().length > 0 && value.trim().length <= max;
}

function validAmount(value, { allowZero = false } = {}) {
  return Number.isFinite(Number(value)) && (allowZero ? Number(value) >= 0 : Number(value) > 0);
}

function statusForStock(stock, threshold) {
  return stock === 0 ? 'Agotado' : stock <= threshold ? 'Bajo Stock' : 'En Stock';
}

async function tableHasColumn(table, column) {
  const [rows] = await db.query(
    `SELECT 1 FROM information_schema.columns WHERE table_schema = ? AND table_name = ? AND column_name = ?`,
    [DB_NAME, table, column]
  );
  return rows.length > 0;
}

async function ensureIndex(table, name, definition, columns) {
  const [rows] = await db.query(
    'SELECT 1 FROM information_schema.statistics WHERE table_schema = ? AND table_name = ? AND index_name = ?',
    [DB_NAME, table, name]
  );
  if (!rows.length) {
    const columnList = columns.map(column => `\`${column}\``).join(', ');
    const indexType = definition ? `${definition} ` : '';
    await db.query(`CREATE ${indexType}INDEX \`${name}\` ON \`${table}\` (${columnList})`);
  }
}

async function addTenantColumn(table) {
  if (!(await tableHasColumn(table, 'business_id'))) {
    await db.query(`ALTER TABLE \`${table}\` ADD COLUMN business_id VARCHAR(36) NULL`);
  }
}

async function initDb() {
  const bootstrap = mysql.createPool(dbConfig);
  await bootstrap.query(`CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
  await bootstrap.end();

  await db.query(`CREATE TABLE IF NOT EXISTS businesses (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB`);
  await db.query(`CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB`);
  await db.query(`CREATE TABLE IF NOT EXISTS roles (
    id VARCHAR(36) PRIMARY KEY,
    business_id VARCHAR(36) NOT NULL,
    name VARCHAR(80) NOT NULL,
    is_system BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_roles_business_name (business_id, name),
    UNIQUE KEY uq_roles_business_id (business_id, id),
    CONSTRAINT fk_roles_business FOREIGN KEY (business_id) REFERENCES businesses(id)
  ) ENGINE=InnoDB`);
  await db.query(`CREATE TABLE IF NOT EXISTS business_memberships (
    business_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    role_id VARCHAR(36) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (business_id, user_id),
    CONSTRAINT fk_membership_business FOREIGN KEY (business_id) REFERENCES businesses(id),
    CONSTRAINT fk_membership_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_membership_role FOREIGN KEY (business_id, role_id) REFERENCES roles(business_id, id)
  ) ENGINE=InnoDB`);
  await db.query(`CREATE TABLE IF NOT EXISTS role_permissions (
    role_id VARCHAR(36) NOT NULL,
    permission_key VARCHAR(80) NOT NULL,
    PRIMARY KEY (role_id, permission_key),
    CONSTRAINT fk_permission_role FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE
  ) ENGINE=InnoDB`);
  await db.query(`CREATE TABLE IF NOT EXISTS sessions (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    token_hash CHAR(64) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_sessions_expiry (expires_at),
    CONSTRAINT fk_session_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_session_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
  ) ENGINE=InnoDB`);

  await db.query(`CREATE TABLE IF NOT EXISTS products (
    id VARCHAR(50) PRIMARY KEY,
    business_id VARCHAR(36) NULL,
    name VARCHAR(100) NOT NULL,
    sku VARCHAR(50) NOT NULL,
    category VARCHAR(100) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    purchasePrice DECIMAL(12,2) NOT NULL DEFAULT 0,
    salePrice DECIMAL(12,2) NOT NULL DEFAULT 0,
    status VARCHAR(50) NOT NULL DEFAULT 'En Stock',
    UNIQUE KEY uq_products_business_sku (business_id, sku),
    INDEX idx_products_business_name (business_id, name)
  ) ENGINE=InnoDB`);
  await db.query(`CREATE TABLE IF NOT EXISTS transactions (
    id VARCHAR(50) PRIMARY KEY,
    business_id VARCHAR(36) NULL,
    date DATE NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(100) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    type VARCHAR(32) NOT NULL,
    status VARCHAR(50) NOT NULL,
    INDEX idx_transactions_business_date (business_id, date)
  ) ENGINE=InnoDB`);
  await db.query(`CREATE TABLE IF NOT EXISTS sales (
    id VARCHAR(50) PRIMARY KEY,
    business_id VARCHAR(36) NULL,
    date DATE NOT NULL,
    productId VARCHAR(50) NOT NULL,
    productName VARCHAR(255) NOT NULL,
    quantity INT NOT NULL,
    unitPrice DECIMAL(12,2) NOT NULL,
    total DECIMAL(12,2) NOT NULL,
    INDEX idx_sales_business_date (business_id, date),
    INDEX idx_sales_business_product (business_id, productId)
  ) ENGINE=InnoDB`);
  await db.query(`CREATE TABLE IF NOT EXISTS settings (
    id VARCHAR(36) PRIMARY KEY,
    business_id VARCHAR(36) NOT NULL,
    ` + '`key`' + ` VARCHAR(100) NOT NULL,
    ` + '`value`' + ` TEXT,
    UNIQUE KEY uq_settings_business_key (business_id, ` + '`key`' + `)
  ) ENGINE=InnoDB`);

  for (const table of ['products', 'sales', 'transactions']) await addTenantColumn(table);
  if (!(await tableHasColumn('settings', 'business_id'))) {
    await db.query('ALTER TABLE settings ADD COLUMN business_id VARCHAR(36) NULL');
    await db.query('ALTER TABLE settings ADD COLUMN id VARCHAR(36) NULL');
    await db.query('UPDATE settings SET id = UUID(), business_id = ? WHERE id IS NULL', ['00000000-0000-4000-8000-000000000001']);
    await db.query('ALTER TABLE settings MODIFY id VARCHAR(36) NOT NULL');
    await db.query('ALTER TABLE settings DROP PRIMARY KEY, ADD PRIMARY KEY (id)');
    await db.query('ALTER TABLE settings ADD UNIQUE KEY uq_settings_business_key (business_id, `key`)');
  }

  const legacyId = '00000000-0000-4000-8000-000000000001';
  const legacyCounts = await Promise.all(['products', 'sales', 'transactions'].map(table =>
    db.query(`SELECT COUNT(*) AS total FROM \`${table}\` WHERE business_id IS NULL`)
  ));
  const [legacySettings] = await db.query('SELECT COUNT(*) AS total FROM settings WHERE business_id IS NULL OR business_id = ?', ['00000000-0000-4000-8000-000000000001']);
  const hasLegacyData = legacyCounts.some(([rows]) => Number(rows[0].total) > 0) || Number(legacySettings[0].total) > 0;
  if (hasLegacyData) {
    await db.query('INSERT IGNORE INTO businesses (id, name) VALUES (?, ?)', [legacyId, process.env.LEGACY_BUSINESS_NAME || 'Negocio con datos anteriores']);
    for (const table of ['products', 'sales', 'transactions']) {
      await db.query(`UPDATE \`${table}\` SET business_id = ? WHERE business_id IS NULL`, [legacyId]);
    }
    await db.query('UPDATE settings SET business_id = ? WHERE business_id IS NULL', [legacyId]);
  }
  const [legacyBusiness] = await db.query('SELECT id FROM businesses WHERE id = ?', [legacyId]);
  if (legacyBusiness.length && process.env.LEGACY_OWNER_EMAIL && process.env.LEGACY_OWNER_PASSWORD) {
    await createInitialOwner(legacyId, process.env.LEGACY_OWNER_EMAIL, process.env.LEGACY_OWNER_PASSWORD, 'Propietario anterior');
    await createStarterRoles(db, legacyId);
  } else if (legacyBusiness.length) {
    console.warn('Hay datos anteriores aislados en un negocio sin propietario. Configura LEGACY_OWNER_EMAIL y LEGACY_OWNER_PASSWORD para asignar acceso.');
  }
  await ensureIndex('products', 'uq_products_business_sku', 'UNIQUE', ['business_id', 'sku']);
  await ensureIndex('products', 'idx_products_business_name', '', ['business_id', 'name']);
  await ensureIndex('transactions', 'idx_transactions_business_date', '', ['business_id', 'date']);
  await ensureIndex('sales', 'idx_sales_business_date', '', ['business_id', 'date']);
  await ensureIndex('sales', 'idx_sales_business_product', '', ['business_id', 'productId']);
  await ensureIndex('settings', 'uq_settings_business_key', 'UNIQUE', ['business_id', 'key']);
  await db.query('DELETE FROM sessions WHERE expires_at <= UTC_TIMESTAMP()');
}

async function createInitialOwner(businessId, email, password, name) {
  const normalizedEmail = email.trim().toLowerCase();
  const [users] = await db.query('SELECT id FROM users WHERE email = ?', [normalizedEmail]);
  const userId = users[0]?.id || crypto.randomUUID();
  if (!users.length) {
    const salt = crypto.randomBytes(16);
    const derived = await hashPassword(password, salt, 64);
    await db.query('INSERT INTO users (id, name, email, password_hash) VALUES (?, ?, ?, ?)', [
      userId, name, normalizedEmail, `scrypt$${salt.toString('hex')}$${derived.toString('hex')}`,
    ]);
  }
  const [existingRoles] = await db.query('SELECT id FROM roles WHERE business_id = ? AND name = ?', [businessId, 'Propietario']);
  const roleId = existingRoles[0]?.id || crypto.randomUUID();
  if (!existingRoles.length) {
    await db.query('INSERT INTO roles (id, business_id, name, is_system) VALUES (?, ?, ?, 1)', [roleId, businessId, 'Propietario']);
    for (const permission of PERMISSIONS) {
      await db.query('INSERT IGNORE INTO role_permissions (role_id, permission_key) VALUES (?, ?)', [roleId, permission.key]);
    }
  }
  await db.query('INSERT IGNORE INTO business_memberships (business_id, user_id, role_id) VALUES (?, ?, ?)', [businessId, userId, roleId]);
}

async function createStarterRoles(connection, businessId) {
  const presets = [
    { name: 'Administrador', permissions: PERMISSIONS.map(item => item.key).filter(key => !['roles:manage'].includes(key)) },
    { name: 'Vendedor', permissions: ['products:read', 'sales:read', 'sales:create'] },
    { name: 'Consulta', permissions: ['products:read', 'sales:read', 'finance:read', 'reports:read'] },
  ];
  for (const preset of presets) {
    const [existing] = await connection.query('SELECT id FROM roles WHERE business_id = ? AND name = ?', [businessId, preset.name]);
    if (existing.length) continue;
    const roleId = crypto.randomUUID();
    await connection.query('INSERT INTO roles (id, business_id, name, is_system) VALUES (?, ?, ?, 1)', [roleId, businessId, preset.name]);
    for (const permission of preset.permissions) {
      await connection.query('INSERT INTO role_permissions (role_id, permission_key) VALUES (?, ?)', [roleId, permission]);
    }
  }
}

app.get('/api/health', async (_req, res, next) => {
  try {
    await db.query('SELECT 1');
    return res.json({ ok: true, database: DB_NAME });
  } catch (err) { return next(err); }
});

app.post('/api/auth/register', requireAllowedOrigin, async (req, res, next) => {
  const { businessName, name, email, password } = req.body || {};
  if (!validText(businessName, 120) || !validText(name, 120) || !validText(email, 190) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
    return fail(res, 400, 'Completa el nombre del negocio, tu nombre y un correo válido.');
  }
  if (typeof password !== 'string' || password.length < 10 || password.length > 200) {
    return fail(res, 400, 'La contraseña debe tener al menos 10 caracteres.');
  }
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const [duplicate] = await connection.query('SELECT id FROM users WHERE email = ?', [email.trim().toLowerCase()]);
    if (duplicate.length) {
      await connection.rollback();
      return fail(res, 409, 'Ya existe una cuenta con ese correo.');
    }
    const businessId = crypto.randomUUID();
    const userId = crypto.randomUUID();
    const roleId = crypto.randomUUID();
    const salt = crypto.randomBytes(16);
    const derived = await hashPassword(password, salt, 64);
    await connection.query('INSERT INTO businesses (id, name) VALUES (?, ?)', [businessId, businessName.trim()]);
    await connection.query('INSERT INTO users (id, name, email, password_hash) VALUES (?, ?, ?, ?)', [
      userId, name.trim(), email.trim().toLowerCase(), `scrypt$${salt.toString('hex')}$${derived.toString('hex')}`,
    ]);
    await connection.query('INSERT INTO roles (id, business_id, name, is_system) VALUES (?, ?, ?, 1)', [roleId, businessId, 'Propietario']);
    for (const permission of PERMISSIONS) {
      await connection.query('INSERT INTO role_permissions (role_id, permission_key) VALUES (?, ?)', [roleId, permission.key]);
    }
    await createStarterRoles(connection, businessId);
    await connection.query('INSERT INTO business_memberships (business_id, user_id, role_id) VALUES (?, ?, ?)', [businessId, userId, roleId]);
    for (const [key, value] of Object.entries({ currency: 'COP', currencySymbol: '$', lowStockThreshold: '10' })) {
      await connection.query('INSERT INTO settings (id, business_id, `key`, `value`) VALUES (?, ?, ?, ?)', [crypto.randomUUID(), businessId, key, value]);
    }
    const token = await saveSession(connection, userId, businessId);
    await connection.commit();
    setSessionCookie(res, token);
    return res.status(201).json({ ok: true });
  } catch (err) {
    await connection.rollback();
    return next(err);
  } finally { connection.release(); }
});

app.post('/api/auth/login', requireAllowedOrigin, async (req, res, next) => {
  const { email, password } = req.body || {};
  if (!validText(email, 190) || typeof password !== 'string') return fail(res, 400, 'Correo o contraseña inválidos.');
  const connection = await db.getConnection();
  try {
    const [users] = await connection.query('SELECT id, name, email, password_hash FROM users WHERE email = ? AND is_active = 1', [email.trim().toLowerCase()]);
    if (!users.length) return fail(res, 401, 'Correo o contraseña inválidos.');
    const user = users[0];
    const [scheme, saltHex, hashHex] = user.password_hash.split('$');
    if (scheme !== 'scrypt' || !saltHex || !hashHex) return fail(res, 401, 'Correo o contraseña inválidos.');
    const candidate = await hashPassword(password, Buffer.from(saltHex, 'hex'), 64);
    const storedHash = Buffer.from(hashHex, 'hex');
    if (candidate.length !== storedHash.length || !crypto.timingSafeEqual(candidate, storedHash)) return fail(res, 401, 'Correo o contraseña inválidos.');
    const memberships = await getMemberships(user.id);
    if (!memberships.length) return fail(res, 403, 'Esta cuenta aún no pertenece a un negocio.');
    await connection.beginTransaction();
    const token = await saveSession(connection, user.id, memberships[0].id);
    await connection.commit();
    setSessionCookie(res, token);
    return res.json({ ok: true });
  } catch (err) {
    if (connection) await connection.rollback().catch(() => {});
    return next(err);
  } finally { connection.release(); }
});

app.get('/api/auth/me', loadSession, async (req, res, next) => {
  try {
    const memberships = await getMemberships(req.auth.userId);
    const [business] = await db.query('SELECT id, name FROM businesses WHERE id = ?', [req.auth.businessId]);
    return res.json({
      user: { id: req.auth.userId, name: req.auth.name, email: req.auth.email },
      business: business[0], role: req.auth.roleName,
      permissions: req.auth.roleName === 'Propietario' ? [...PERMISSION_KEYS] : [...req.auth.permissions],
      businesses: memberships,
    });
  } catch (err) { return next(err); }
});

app.post('/api/auth/logout', requireAllowedOrigin, async (req, res, next) => {
  try {
    const token = parseCookies(req.headers.cookie)[COOKIE_NAME];
    if (token) await db.query('DELETE FROM sessions WHERE token_hash = ?', [tokenHash(token)]);
    clearSessionCookie(res);
    return res.sendStatus(204);
  } catch (err) { return next(err); }
});

app.post('/api/auth/select-business', requireAllowedOrigin, loadSession, async (req, res, next) => {
  const businessId = req.body?.businessId;
  if (!validText(businessId, 36)) return fail(res, 400, 'Selecciona un negocio válido.');
  try {
    const [membership] = await db.query('SELECT 1 FROM business_memberships WHERE user_id = ? AND business_id = ? AND is_active = 1', [req.auth.userId, businessId]);
    if (!membership.length) return fail(res, 403, 'No perteneces a ese negocio.');
    await db.query('UPDATE sessions SET business_id = ? WHERE id = ?', [businessId, req.auth.sessionId]);
    return res.sendStatus(204);
  } catch (err) { return next(err); }
});

app.get('/api/permissions', loadSession, requirePermission('roles:manage'), (_req, res) => res.json(PERMISSIONS));

app.get('/api/roles', loadSession, requireAnyPermission('roles:manage', 'users:manage'), async (req, res, next) => {
  try {
    const [roles] = await db.query('SELECT id, name, is_system AS isSystem FROM roles WHERE business_id = ? ORDER BY is_system DESC, name', [req.auth.businessId]);
    for (const role of roles) {
      const [rows] = await db.query('SELECT permission_key FROM role_permissions WHERE role_id = ?', [role.id]);
      role.permissions = role.name === 'Propietario' ? [...PERMISSION_KEYS] : rows.map(row => row.permission_key);
    }
    return res.json({ roles, permissions: PERMISSIONS });
  } catch (err) { return next(err); }
});

app.post('/api/roles', requireAllowedOrigin, loadSession, requirePermission('roles:manage'), async (req, res, next) => {
  const { name, permissions } = req.body || {};
  if (!validText(name, 80) || !Array.isArray(permissions) || permissions.some(key => !PERMISSION_KEYS.has(key))) return fail(res, 400, 'Nombre o permisos de rol inválidos.');
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const id = crypto.randomUUID();
    await connection.query('INSERT INTO roles (id, business_id, name) VALUES (?, ?, ?)', [id, req.auth.businessId, name.trim()]);
    for (const permission of new Set(permissions)) await connection.query('INSERT INTO role_permissions (role_id, permission_key) VALUES (?, ?)', [id, permission]);
    await connection.commit();
    return res.status(201).json({ id, name: name.trim(), permissions: [...new Set(permissions)] });
  } catch (err) {
    await connection.rollback();
    if (err.code === 'ER_DUP_ENTRY') return fail(res, 409, 'Ya existe un rol con ese nombre.');
    return next(err);
  } finally { connection.release(); }
});

app.put('/api/roles/:id', requireAllowedOrigin, loadSession, requirePermission('roles:manage'), async (req, res, next) => {
  const { name, permissions } = req.body || {};
  if (!validText(name, 80) || !Array.isArray(permissions) || permissions.some(key => !PERMISSION_KEYS.has(key))) return fail(res, 400, 'Nombre o permisos de rol inválidos.');
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const [roles] = await connection.query('SELECT name FROM roles WHERE id = ? AND business_id = ? FOR UPDATE', [req.params.id, req.auth.businessId]);
    if (!roles.length) { await connection.rollback(); return fail(res, 404, 'No se encontró el rol.'); }
    if (roles[0].name === 'Propietario') { await connection.rollback(); return fail(res, 403, 'El rol Propietario conserva siempre todos los permisos.'); }
    await connection.query('UPDATE roles SET name = ? WHERE id = ?', [name.trim(), req.params.id]);
    await connection.query('DELETE FROM role_permissions WHERE role_id = ?', [req.params.id]);
    for (const permission of new Set(permissions)) await connection.query('INSERT INTO role_permissions (role_id, permission_key) VALUES (?, ?)', [req.params.id, permission]);
    await connection.commit();
    return res.json({ id: req.params.id, name: name.trim(), permissions: [...new Set(permissions)] });
  } catch (err) {
    await connection.rollback();
    if (err.code === 'ER_DUP_ENTRY') return fail(res, 409, 'Ya existe un rol con ese nombre.');
    return next(err);
  } finally { connection.release(); }
});

app.delete('/api/roles/:id', requireAllowedOrigin, loadSession, requirePermission('roles:manage'), async (req, res, next) => {
  try {
    const [roles] = await db.query('SELECT name, is_system FROM roles WHERE id = ? AND business_id = ?', [req.params.id, req.auth.businessId]);
    if (!roles.length) return fail(res, 404, 'No se encontró el rol.');
    if (roles[0].name === 'Propietario' || roles[0].is_system) return fail(res, 403, 'Los roles del sistema no se pueden eliminar.');
    const [members] = await db.query('SELECT COUNT(*) AS total FROM business_memberships WHERE business_id = ? AND role_id = ?', [req.auth.businessId, req.params.id]);
    if (Number(members[0].total)) return fail(res, 409, 'Reasigna los usuarios de este rol antes de eliminarlo.');
    await db.query('DELETE FROM roles WHERE id = ? AND business_id = ?', [req.params.id, req.auth.businessId]);
    return res.sendStatus(204);
  } catch (err) { return next(err); }
});

app.get('/api/members', loadSession, requirePermission('users:manage'), async (req, res, next) => {
  try {
    const [rows] = await db.query(
      `SELECT u.id, u.name, u.email, m.is_active AS isActive, r.id AS roleId, r.name AS roleName
         FROM business_memberships m JOIN users u ON u.id = m.user_id JOIN roles r ON r.id = m.role_id
        WHERE m.business_id = ? ORDER BY u.name`, [req.auth.businessId]
    );
    return res.json(rows);
  } catch (err) { return next(err); }
});

app.post('/api/members', requireAllowedOrigin, loadSession, requirePermission('users:manage'), async (req, res, next) => {
  const { name, email, password, roleId } = req.body || {};
  if (!validText(name, 120) || !validText(email, 190) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()) || !validText(roleId, 36)) return fail(res, 400, 'Completa nombre, correo y rol válido.');
  if (typeof password !== 'string' || password.length < 10) return fail(res, 400, 'La contraseña inicial debe tener al menos 10 caracteres.');
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const [roles] = await connection.query('SELECT id FROM roles WHERE id = ? AND business_id = ?', [roleId, req.auth.businessId]);
    if (!roles.length) { await connection.rollback(); return fail(res, 400, 'El rol no pertenece a este negocio.'); }
    const normalizedEmail = email.trim().toLowerCase();
    const [existing] = await connection.query('SELECT id FROM users WHERE email = ?', [normalizedEmail]);
    let userId = existing[0]?.id;
    if (userId) {
      const [membership] = await connection.query('SELECT 1 FROM business_memberships WHERE business_id = ? AND user_id = ?', [req.auth.businessId, userId]);
      if (membership.length) { await connection.rollback(); return fail(res, 409, 'Este usuario ya pertenece al negocio.'); }
    } else {
      userId = crypto.randomUUID();
      const salt = crypto.randomBytes(16);
      const derived = await hashPassword(password, salt, 64);
      await connection.query('INSERT INTO users (id, name, email, password_hash) VALUES (?, ?, ?, ?)', [
        userId, name.trim(), normalizedEmail, `scrypt$${salt.toString('hex')}$${derived.toString('hex')}`,
      ]);
    }
    await connection.query('INSERT INTO business_memberships (business_id, user_id, role_id) VALUES (?, ?, ?)', [req.auth.businessId, userId, roleId]);
    await connection.commit();
    return res.status(201).json({ id: userId, name: name.trim(), email: normalizedEmail, roleId });
  } catch (err) {
    await connection.rollback();
    if (err.code === 'ER_DUP_ENTRY') return fail(res, 409, 'El correo ya está registrado.');
    return next(err);
  } finally { connection.release(); }
});

app.put('/api/members/:userId', requireAllowedOrigin, loadSession, requirePermission('users:manage'), async (req, res, next) => {
  const { roleId, isActive } = req.body || {};
  if (!validText(roleId, 36) || typeof isActive !== 'boolean') return fail(res, 400, 'Rol o estado inválido.');
  if (req.params.userId === req.auth.userId && !isActive) return fail(res, 400, 'No puedes desactivar tu propia cuenta.');
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const [roles] = await connection.query('SELECT id FROM roles WHERE id = ? AND business_id = ?', [roleId, req.auth.businessId]);
    const [members] = await connection.query('SELECT role_id AS roleId FROM business_memberships WHERE business_id = ? AND user_id = ? FOR UPDATE', [req.auth.businessId, req.params.userId]);
    if (!roles.length || !members.length) { await connection.rollback(); return fail(res, 404, 'No se encontró el usuario o el rol en este negocio.'); }
    const [oldRoles] = await connection.query('SELECT name FROM roles WHERE id = ?', [members[0].roleId]);
    if (oldRoles[0]?.name === 'Propietario') { await connection.rollback(); return fail(res, 403, 'No se puede quitar ni cambiar el rol del propietario principal.'); }
    await connection.query('UPDATE business_memberships SET role_id = ?, is_active = ? WHERE business_id = ? AND user_id = ?', [roleId, isActive, req.auth.businessId, req.params.userId]);
    if (!isActive) await connection.query('DELETE FROM sessions WHERE user_id = ? AND business_id = ?', [req.params.userId, req.auth.businessId]);
    await connection.commit();
    return res.sendStatus(204);
  } catch (err) { await connection.rollback(); return next(err); }
  finally { connection.release(); }
});

app.get('/api/products', loadSession, requirePermission('products:read'), async (req, res, next) => {
  try {
    const settings = await getTenantSettings(req.auth.businessId);
    const threshold = Number(settings.lowStockThreshold) || 10;
    const [rows] = await db.query(
      `SELECT id, name, sku, category, stock, purchasePrice, salePrice FROM products
        WHERE business_id = ? ORDER BY name`, [req.auth.businessId]
    );
    return res.json(rows.map(product => ({ ...product, status: statusForStock(Number(product.stock), threshold) })));
  } catch (err) { return next(err); }
});

app.post('/api/products', requireAllowedOrigin, loadSession, requirePermission('products:create'), async (req, res, next) => {
  const { id, name, sku, category, stock, purchasePrice, salePrice } = req.body || {};
  if (!validText(name, 100) || !validText(sku, 50) || !validText(category, 100) || !Number.isInteger(Number(stock)) || Number(stock) < 0 || !validAmount(purchasePrice, { allowZero: true }) || !validAmount(salePrice)) return fail(res, 400, 'Revisa nombre, SKU, categoría, stock y precios.');
  try {
    const settings = await getTenantSettings(req.auth.businessId);
    const threshold = Number(settings.lowStockThreshold) || 10;
    await db.query(
      'INSERT INTO products (id, business_id, name, sku, category, stock, purchasePrice, salePrice, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [id || crypto.randomUUID(), req.auth.businessId, name.trim(), sku.trim(), category.trim(), Number(stock), Number(purchasePrice), Number(salePrice), statusForStock(Number(stock), threshold)]
    );
    return res.sendStatus(201);
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return fail(res, 409, 'Ya existe un producto con ese SKU en este negocio.');
    return next(err);
  }
});

app.put('/api/products/:id', requireAllowedOrigin, loadSession, requirePermission('products:update'), async (req, res, next) => {
  const { name, sku, category, stock, purchasePrice, salePrice } = req.body || {};
  if (!validText(name, 100) || !validText(sku, 50) || !validText(category, 100) || !Number.isInteger(Number(stock)) || Number(stock) < 0 || !validAmount(purchasePrice, { allowZero: true }) || !validAmount(salePrice)) return fail(res, 400, 'Revisa nombre, SKU, categoría, stock y precios.');
  try {
    const [current] = await db.query('SELECT stock FROM products WHERE id = ? AND business_id = ?', [req.params.id, req.auth.businessId]);
    if (!current.length) return fail(res, 404, 'No se encontró el producto en este negocio.');
    const settings = await getTenantSettings(req.auth.businessId);
    const threshold = Number(settings.lowStockThreshold) || 10;
    const [result] = await db.query(
      `UPDATE products SET name=?, sku=?, category=?, stock=?, purchasePrice=?, salePrice=?, status=?
        WHERE id=? AND business_id=?`,
      [name.trim(), sku.trim(), category.trim(), Number(stock), Number(purchasePrice), Number(salePrice), statusForStock(Number(stock), threshold), req.params.id, req.auth.businessId]
    );
    if (!result.affectedRows) return fail(res, 404, 'No se encontró el producto en este negocio.');
    return res.sendStatus(204);
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return fail(res, 409, 'Ya existe un producto con ese SKU en este negocio.');
    return next(err);
  }
});

app.delete('/api/products/:id', requireAllowedOrigin, loadSession, requirePermission('products:delete'), async (req, res, next) => {
  try {
    const [result] = await db.query('DELETE FROM products WHERE id = ? AND business_id = ?', [req.params.id, req.auth.businessId]);
    if (!result.affectedRows) return fail(res, 404, 'No se encontró el producto en este negocio.');
    return res.sendStatus(204);
  } catch (err) { return next(err); }
});

app.get('/api/transactions', loadSession, requirePermission('finance:read'), async (req, res, next) => {
  try {
    const [rows] = await db.query('SELECT id, date, description, category, amount, type, status FROM transactions WHERE business_id = ? ORDER BY date DESC, id DESC', [req.auth.businessId]);
    return res.json(rows);
  } catch (err) { return next(err); }
});

app.post('/api/transactions', requireAllowedOrigin, loadSession, requirePermission('finance:create'), async (req, res, next) => {
  const { id, date, description, category, amount, type, status } = req.body || {};
  if (!validText(date, 10) || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !validText(description, 1000) || !validText(category, 100) || !validAmount(amount) || !['income', 'expense'].includes(type) || !['Completado', 'Pendiente', 'Cancelado'].includes(status)) return fail(res, 400, 'Revisa fecha, descripción, categoría, monto, tipo y estado.');
  try {
    await db.query('INSERT INTO transactions (id, business_id, date, description, category, amount, type, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [id || crypto.randomUUID(), req.auth.businessId, date, description.trim(), category.trim(), Number(amount), type, status]);
    return res.sendStatus(201);
  } catch (err) { return next(err); }
});

app.put('/api/transactions/:id', requireAllowedOrigin, loadSession, requirePermission('finance:update'), async (req, res, next) => {
  const { date, description, category, amount, type, status } = req.body || {};
  if (!validText(date, 10) || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !validText(description, 1000) || !validText(category, 100) || !validAmount(amount) || !['income', 'expense'].includes(type) || !['Completado', 'Pendiente', 'Cancelado'].includes(status)) return fail(res, 400, 'Revisa los datos del movimiento.');
  try {
    const [result] = await db.query('UPDATE transactions SET date=?, description=?, category=?, amount=?, type=?, status=? WHERE id=? AND business_id=?',
      [date, description.trim(), category.trim(), Number(amount), type, status, req.params.id, req.auth.businessId]);
    if (!result.affectedRows) return fail(res, 404, 'No se encontró el movimiento en este negocio.');
    return res.sendStatus(204);
  } catch (err) { return next(err); }
});

app.delete('/api/transactions/:id', requireAllowedOrigin, loadSession, requirePermission('finance:delete'), async (req, res, next) => {
  try {
    const [result] = await db.query('DELETE FROM transactions WHERE id=? AND business_id=?', [req.params.id, req.auth.businessId]);
    if (!result.affectedRows) return fail(res, 404, 'No se encontró el movimiento en este negocio.');
    return res.sendStatus(204);
  } catch (err) { return next(err); }
});

app.get('/api/sales', loadSession, requirePermission('sales:read'), async (req, res, next) => {
  try {
    const [rows] = await db.query('SELECT id, date, productId, productName, quantity, unitPrice, total FROM sales WHERE business_id = ? ORDER BY date DESC, id DESC', [req.auth.businessId]);
    return res.json(rows);
  } catch (err) { return next(err); }
});

app.post('/api/sales', requireAllowedOrigin, loadSession, requirePermission('sales:create'), async (req, res, next) => {
  const { productId, quantity } = req.body || {};
  if (!validText(productId, 50) || !Number.isInteger(Number(quantity)) || Number(quantity) <= 0) return fail(res, 400, 'Selecciona un producto y una cantidad válida.');
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const [products] = await connection.query('SELECT id, name, stock, salePrice FROM products WHERE id = ? AND business_id = ? FOR UPDATE', [productId, req.auth.businessId]);
    if (!products.length) { await connection.rollback(); return fail(res, 404, 'No se encontró el producto en este negocio.'); }
    const product = products[0];
    if (Number(product.stock) < Number(quantity)) { await connection.rollback(); return fail(res, 409, 'No hay suficientes unidades disponibles.'); }
    const settings = await getTenantSettings(req.auth.businessId);
    const threshold = Number(settings.lowStockThreshold) || 10;
    const total = Number((Number(product.salePrice) * Number(quantity)).toFixed(2));
    const date = new Date().toISOString().slice(0, 10);
    const saleId = crypto.randomUUID();
    const newStock = Number(product.stock) - Number(quantity);
    await connection.query('INSERT INTO sales (id, business_id, date, productId, productName, quantity, unitPrice, total) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [saleId, req.auth.businessId, date, product.id, product.name, Number(quantity), Number(product.salePrice), total]);
    await connection.query('UPDATE products SET stock = ?, status = ? WHERE id = ? AND business_id = ?',
      [newStock, statusForStock(newStock, threshold), product.id, req.auth.businessId]);
    await connection.query('INSERT INTO transactions (id, business_id, date, description, category, amount, type, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [crypto.randomUUID(), req.auth.businessId, date, `Venta: ${product.name} ×${quantity}`, 'Ventas', total, 'income', 'Completado']);
    await connection.commit();
    return res.status(201).json({ id: saleId, date, productId: product.id, productName: product.name, quantity: Number(quantity), unitPrice: Number(product.salePrice), total, stock: newStock });
  } catch (err) { await connection.rollback(); return next(err); }
  finally { connection.release(); }
});

app.get('/api/settings', loadSession, requirePermission('settings:read'), async (req, res, next) => {
  try {
    const [businesses] = await db.query('SELECT name FROM businesses WHERE id = ?', [req.auth.businessId]);
    return res.json({ ...(await getTenantSettings(req.auth.businessId)), businessName: businesses[0]?.name || '' });
  }
  catch (err) { return next(err); }
});

app.put('/api/settings', requireAllowedOrigin, loadSession, requirePermission('settings:update'), async (req, res, next) => {
  const allowed = ['businessName', 'ownerName', 'ownerEmail', 'currency', 'currencySymbol', 'lowStockThreshold'];
  const updates = req.body || {};
  if (Object.keys(updates).some(key => !allowed.includes(key))) return fail(res, 400, 'La configuración contiene campos no permitidos.');
  if (updates.businessName !== undefined && !validText(updates.businessName, 120)) return fail(res, 400, 'El nombre del negocio es obligatorio.');
  if (updates.ownerEmail !== undefined && updates.ownerEmail !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(updates.ownerEmail)) return fail(res, 400, 'Ingresa un correo válido para el propietario.');
  if (updates.lowStockThreshold !== undefined && (!Number.isInteger(Number(updates.lowStockThreshold)) || Number(updates.lowStockThreshold) < 0)) return fail(res, 400, 'El umbral de stock debe ser un entero igual o mayor a cero.');
  if (updates.currency !== undefined && !/^[A-Z]{3}$/.test(updates.currency)) return fail(res, 400, 'Usa un código de moneda de tres letras.');
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    for (const [key, value] of Object.entries(updates)) {
      if (key === 'businessName') {
        await connection.query('UPDATE businesses SET name = ? WHERE id = ?', [String(value).trim(), req.auth.businessId]);
        continue;
      }
      await connection.query('INSERT INTO settings (id, business_id, `key`, `value`) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)',
        [crypto.randomUUID(), req.auth.businessId, key, String(value)]);
    }
    if (updates.lowStockThreshold !== undefined) {
      const threshold = Number(updates.lowStockThreshold);
      await connection.query('UPDATE products SET status = CASE WHEN stock = 0 THEN \'Agotado\' WHEN stock <= ? THEN \'Bajo Stock\' ELSE \'En Stock\' END WHERE business_id = ?', [threshold, req.auth.businessId]);
    }
    await connection.commit();
    return res.sendStatus(204);
  } catch (err) { await connection.rollback(); return next(err); }
  finally { connection.release(); }
});

app.use((err, _req, res, _next) => {
  console.error(err);
  if (res.headersSent) return;
  return res.status(500).json({ error: 'Ocurrió un error al procesar la solicitud.' });
});

async function start() {
  try {
    const bootstrap = mysql.createPool(dbConfig);
    await bootstrap.query(`CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    await bootstrap.end();
    await initDb();
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  } catch (err) {
    console.error('No se pudo iniciar MySQL. Revisa server/.env y que el servicio esté activo.');
    console.error(err.message);
    process.exit(1);
  }
}

start();
